import 'dart:ffi';

import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stockpathshala_beta/model/models/auth_models/sign_in.dart';
import 'package:stockpathshala_beta/model/models/batch_models/all_batch_model.dart';
import 'package:stockpathshala_beta/model/network_calls/api_helper/provider_helper/batch_provider.dart';
import 'package:stockpathshala_beta/model/services/auth_service.dart';
import 'package:stockpathshala_beta/service/utils/Session.dart';
import 'package:stockpathshala_beta/view/screens/root_view/live_classes_view/live_classes_view.dart';
import 'package:stockpathshala_beta/view_model/controllers/root_view_controller/root_view_controller.dart';
import '../../../../model/models/common_container_model/common_container_model.dart';
import '../../../../model/models/live_class_model/live_class_model.dart';
import '../../../../model/network_calls/api_helper/provider_helper/live_provider.dart';
import '../../../../model/network_calls/dio_client/get_it_instance.dart';
import '../../../../model/services/pagination.dart';
import '../../../../view/widgets/log_print/log_print_condition.dart';
import '../../../../view/widgets/toast_view/showtoast.dart';
import '../live_classes_controller/filter_controller/filter_controller.dart';

class PastClassesController extends GetxController {
  LiveProvider liveProvider = getIt();
  BatchProvider batchProvider = getIt();
  Rx<TextEditingController> searchController = TextEditingController().obs;

  // RxList<DropDownData> listOFSelectedLang = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedCat = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedDays = <DropDownData>[].obs;

  // RxList<DropDownData> selectedLevel = <DropDownData>[].obs;
  RxList<RatingDataVal> selectedRating = <RatingDataVal>[].obs;
  Rx<DropDownData> selectedSub = DropDownData().obs;
  RxList<DropDownData> listOFSelectedDuration = <DropDownData>[].obs;
  Rx<LiveClassModel> liveData = LiveClassModel().obs;
  RxList<DropDownData> listofSelectedTeacher = <DropDownData>[].obs;
  late Rx<PagingScrollController<CommonDatum>> dataPagingController;
  RxBool isDataLoading = false.obs;
  RxBool isClearLoading = false.obs;

  RxBool isShow = false.obs;
  RxList<RxBool> isTrialList =
      <RxBool>[].obs; // Stores is_trial values for each item

  RxInt countValue = 0.obs;
  RxString searchKey = "".obs;

  // AllUserSubscription _sub = AllUserSubscription();
  RxList<BuyBatchData> userSub = <BuyBatchData>[].obs;
  RxList<BatchData> batchList = <BatchData>[].obs;
  RxList<BatchData> filteredBatchList =
      <BatchData>[].obs; // New list for filtered results

  Rx<AllBatchesModal> batchData = AllBatchesModal().obs;
  late TabController tabController;
  RxBool isBatchesLoading = false.obs;
  List<Tab> tabs = [
    const Tab(text: 'Batch Classes'),
    const Tab(text: 'Demo Classes')
  ];

  @override
  void onInit() {
    dataPagingController = PagingScrollController<CommonDatum>(
        onLoadMore: (int page, int totalItemsCount) {
          getLiveData(
            pageNo: page,
            teacherId: listofSelectedTeacher
                .map((element) => element.id)
                .toList()
                .toString()
                .replaceAll("[", "")
                .replaceAll("]", "")
                .removeAllWhitespace,
          );
        }, getStartPage: () {
      return 1;
    }, getThreshold: () {
      return 0;
    }).obs;

    getSubscrpitions();
    getBatches();
    filteredBatchList.assignAll(batchList);
    getLiveData(pageNo: 1);
    super.onInit();
  }

  Future<void> onRefresh() async {
    isBatchesLoading.value = true;
    isTrialList.clear();
    await getSubscrpitions();
    await getBatches();
    await getLiveData(pageNo: 1);
  }

  getSubscrpitions() async {
    List<AllUserSubscription> userData =
        Get.find<AuthService>().user.value.allUserSubscription ?? [];
    // if (userData.isNotEmpty) {
    //   _sub = userData.first;
    // }

    userSub.value = List<BuyBatchData>.from(
        userData.map((e) => BuyBatchData.fromJson(e.toJson())));
  }

  Future<void> getBatches() async {
    isBatchesLoading.value = true;
    await batchProvider.getPastBatches(onError: (message, json) {
      toastShow(message: message);
      isBatchesLoading.value = false;
    }, onSuccess: (message, json) {
      batchData.value = AllBatchesModal.fromJson(json ?? {}, true);
      List<BatchData> list = [];

      if (batchData.value.data?.isNotEmpty ?? false) {
        /// made for new subscription model, not required with old
        // if (!(_sub.superSubscription == 1 || _sub.pastSubscription == 1)) {
        //   for (var data in batchData.value.data!) {
        //     for (var subs in userSub) {
        //       if (!list.any((element) => element.id == data.id)) {
        //         list.addIf(data.id == subs.id, data);
        //       }
        //     }
        //   }
        // } else {

        list = batchData.value.data ?? [];

        //   }
      }
      batchList.value = list;
    });
    isBatchesLoading.value = false;
  }

  List<SubBatch>? filterSubBatches({required int batchId}) {
    /// made for new subscription model, not required with old
    // List<SubBatch>? list = [];

    // if (!(_sub.superSubscription == 1 || _sub.pastSubscription == 1)) {
    //   for (var data in userSub) {
    //     list.addIf(data.id == batchId, SubBatch.fromJson(data.toJson()));
    //   }
    //   return list;
    // }
    return null;
  }

  onFilterApply() {
    // getLiveData(
    //     pageNo: 1,
    //     categoryId: selectedCategory.value,
    //     langId: selectedLang.value,
    //     levelId: selectedLevel.value,
    //     duration: selectedDuration.value,
    //     rating: selectedRating.value,
    //     subscriptionLevel: selectedSubscription.value);
  }

  onClassSearch(val) {
    EasyDebounce.debounce(
        countValue.value.toString(), const Duration(milliseconds: 1000),
            () async {
          // if(!pastBatches){
          print('sdcfsdcs');
          getLiveData(
            pageNo: 1,
            searchKeyWord: val,
            teacherId: listofSelectedTeacher
                .map((element) => element.id)
                .toList()
                .toString()
                .replaceAll("[", "")
                .replaceAll("]", "")
                .removeAllWhitespace,
          );
          countValue.value++;
          // }
        });
    if (val.isEmpty) {
      // Clear `filteredBatchList` when there's no search input
      filteredBatchList.clear();
    } else {
      // Filter and update `filteredBatchList` when query is entered
      filteredBatchList.assignAll(
        batchList
            .where((batch) =>
        batch.title?.toLowerCase().contains(val.toLowerCase()) ?? false)
            .toList(),
      );
    }
  }

  getLiveData({
    required int pageNo,
    String? searchKeyWord,
    String? categoryId,
    String? langId,
    String? teacherId,
    String? dateFilter,
    String? levelId,
    String? duration,
    String? rating,
    String? subscriptionLevel,
  }) async {
    searchKey.value = searchKeyWord ?? "";
    print('sdfdc $searchKeyWord');
    print('getDateFilterDatasb past  $categoryId');
    print('getDateFilterDatasb past1  $dateFilter');

    if (pageNo != 1) {
      dataPagingController.value.isDataLoading.value = true;
    } else {
      dataPagingController.value.isDataLoading.value = false;
      dataPagingController.value.reset();
      isDataLoading.value = true;
    }
    await liveProvider.getLiveData(
      searchKeyWord: searchKey.value,
      onError: (message, errorMap) {
        toastShow(message: message);
        isDataLoading.value = false;
      },
      onSuccess: (message, json) {
        print("Date Filter Applieds: $dateFilter");
        liveData.value = LiveClassModel.fromJson(json!);
        logPrint("sabdjhas ${liveData.value}");

        List newItems = json['data']['data'];
        isTrialList.clear();
        for (var item in newItems) {
          bool isTrial = item['is_trial'] == 1; // Check `is_trial` field
          isTrialList.add(RxBool(isTrial)); // Dynamically add new RxBool items
        }

        // Filter by category if needed (already handled by API if sent)
        List<CommonDatum> allData = liveData.value.data?.data?.map((x) => CommonDatum.fromJson(x.toJson())).toList() ?? [];

        // Filter by days (end_date) if dateFilter is provided
        List<CommonDatum> filteredData = allData;
        if (dateFilter != null && dateFilter.isNotEmpty) {
          DateTime now = DateTime.now();
          DateTime start;
          DateTime end;
          switch (dateFilter) {
            case 'today':
              start = DateTime(now.year, now.month, now.day);
              end = DateTime(now.year, now.month, now.day, 23, 59, 59);
              break;
            case 'yesterday':
              final yesterday = now.subtract(Duration(days: 1));
              start = DateTime(yesterday.year, yesterday.month, yesterday.day);
              end = DateTime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59);
              break;
            case 'last_week':
              final weekDay = now.weekday;
              final lastMonday = now.subtract(Duration(days: weekDay + 6));
              final lastSunday = lastMonday.add(Duration(days: 6));
              start = DateTime(lastMonday.year, lastMonday.month, lastMonday.day);
              end = DateTime(lastSunday.year, lastSunday.month, lastSunday.day, 23, 59, 59);
              break;
            case 'this_month':
              start = DateTime(now.year, now.month, 1);
              end = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
              break;
            default:
              start = DateTime(1970);
              end = now;
          }
          filteredData = allData.where((item) {
            final endDate = item.updatedAt ?? item.createdAt ?? item.startTime;
            if (endDate == null) return false;
            return endDate.isAfter(start.subtract(const Duration(seconds: 1))) && endDate.isBefore(end.add(const Duration(seconds: 1)));
          }).toList();
        }

        dataPagingController.value.list.clear();
        dataPagingController.value.list.addAll(filteredData);
        isDataLoading.value = false;
      },
      isPast: true,
      pageNo: pageNo,
      categoryId: categoryId,
      teacherId: teacherId,
      dateFilter: dateFilter,
      langId: langId,
      levelId: levelId,
      duration: duration,
      rating: selectedRating
          .map((element) => element.ratingValue)
          .toList()
          .toString()
          .replaceAll("[", "")
          .replaceAll("]", "")
          .removeAllWhitespace,
      subscriptionLevel: subscriptionLevel,
    );
    if (pageNo != 1) {
      // dataPagingController.value.isDataLoading.value = false;
    }
  }
}

class BuyBatchData {
  final int? id;
  final int? subBatch;
  final String? subBatchText;

  BuyBatchData(
      {required this.id, required this.subBatch, required this.subBatchText});

  factory BuyBatchData.fromJson(Map<String, dynamic> json) => BuyBatchData(
      id: json['batch_id'],
      subBatch: json['batch_start_date'],
      subBatchText: json['batches_dates']);

  Map<String, dynamic> toJson() => {
    'batch_id': id,
    'id': subBatch,
    'start_date': subBatchText,
  };
}