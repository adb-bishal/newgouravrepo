import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:stockpathshala_beta/view/screens/root_view/live_classes_view/live_classes_view.dart';
import 'package:stockpathshala_beta/view_model/controllers/root_view_controller/root_view_controller.dart';

import '../../../../../model/models/explore_all_category/all_category_model.dart' as category;
import '../../../../../model/network_calls/api_helper/provider_helper/courses_provider.dart';
import '../../../../../model/network_calls/dio_client/get_it_instance.dart';
import '../../../../../model/services/auth_service.dart';
import '../../../../../view/widgets/log_print/log_print_condition.dart';
import '../../../../../view/widgets/toast_view/showtoast.dart';

// class ClassesFilterController extends GetxController {
//   ClassesFilterController({
//     DropDownData? selectedSubscription,
//     required List<DropDownData> listOSelectedCat,
//   }) {
//     Future.delayed(Duration.zero, () {
//       listOFSelectedCat.value = [];
//       listOFSelectedCat.addAll(listOSelectedCat);
//     });
//
//     selectedSub = DropDownData(id: "0", optionName: subscriptionData[0].toLowerCase()).obs;
//
//     selectedSub.value = DropDownData(
//       id: selectedSubscription?.id ?? "0",
//       optionName: selectedSubscription?.optionName ?? subscriptionData[0].toLowerCase(),
//     );
//
//     if (selectedSubscription?.optionName == "free") {
//       selectedSubscriptionFilter.value = 1;
//     } else if (selectedSubscription?.optionName == "pro") {
//       selectedSubscriptionFilter.value = 2;
//     } else {
//       selectedSubscriptionFilter.value = 0;
//     }
//
//     logPrint("selected sub in constructor ${selectedSub.value.optionName}");
//   }
//
//   final List<DropDownData> dayFilterList = [
//     DropDownData(id: "today", optionName: "Today"),
//     DropDownData(id: "yesterday", optionName: "Yesterday"),
//     DropDownData(id: "last_week", optionName: "Last Week"),
//     DropDownData(id: "this_month", optionName: "This Month"),
//   ];
//
//
//   RxList<DropDownData> levelData = Get.find<AuthService>().levelData;
//   RxList<DropDownData> selectedLevel = <DropDownData>[].obs;
//   RxList<DropDownData> categoryList = <DropDownData>[].obs;
//   RxList<DropDownData> durationList = <DropDownData>[
//     DropDownData(id: "1", optionName: "15", displayName: "15 Minutes"),
//     DropDownData(id: "2", optionName: "30", displayName: "30 Minutes"),
//     DropDownData(id: "3", optionName: "45", displayName: "45 Minutes"),
//     DropDownData(id: "4", optionName: "60", displayName: "60 Minutes"),
//     DropDownData(id: "5", optionName: "90", displayName: "90 Minutes"),
//   ].obs;
//
//   RxList<DropDownData> langList = Get.find<RootViewController>().languageData;
//   RxList<String> subscriptionData = <String>["All", "Free", "Pro"].obs;
//   RxInt selectedSubscriptionFilter = 0.obs;
//
//   RxList<DropDownData> teacherList = <DropDownData>[].obs;
//   RxList<DropDownData> listOfSelectedTeacher = <DropDownData>[].obs;
//   RxList<DropDownData> listOFSelectedDuration = <DropDownData>[].obs;
//   RxList<DropDownData> listOFSelectedLang = <DropDownData>[].obs;
//   RxList<DropDownData> listOFSelectedCat = <DropDownData>[].obs;
//   RxList<DropDownData> listSelectedDate = <DropDownData>[].obs;
//
//   RxList<RatingDataVal> selectedRating = <RatingDataVal>[
//     RatingDataVal(
//       ratingName: "All",
//       ratingValue: "all",
//     ),
//   ].obs;
//
//   late Rx<DropDownData> selectedSub;
//
//   RxList<RatingDataVal> ratingData = <RatingDataVal>[
//     RatingDataVal(ratingName: "All", ratingValue: "all"),
//     RatingDataVal(ratingName: "5 star", ratingValue: "5"),
//     RatingDataVal(ratingName: "4 star", ratingValue: "4"),
//     RatingDataVal(ratingName: "3 star", ratingValue: "3"),
//     RatingDataVal(ratingName: "2 star", ratingValue: "2"),
//     RatingDataVal(ratingName: "1 star", ratingValue: "1"),
//   ].obs;
//
//   CourseProvider courseProvider = getIt();
//   RxBool isCategoryLoading = false.obs;
//   RxBool isDaysLoading = false.obs;
//   RxBool isDataLoading = false.obs;
//   RxBool isTeacherLoading = false.obs;
//
//   @override
//   void onInit() async {
//     getAllCategory();
//     if (levelData.isNotEmpty) {
//       if (!(levelData.any((element) => element.optionName == "All"))) {
//         levelData.insert(0, DropDownData(optionName: "All", id: "0"));
//       }
//
//       final classLevel = await Get.find<AuthService>().getClassLevel();
//       if (classLevel.isEmpty) {
//         selectedLevel.add(
//           DropDownData(
//             id: Get.find<AuthService>().user.value.level?.id.toString(),
//             displayName: null,
//             optionName: Get.find<AuthService>().user.value.level?.level?.toLowerCase(),
//           ),
//         );
//       }
//
//       selectedLevel.addAll(classLevel.toSet().toList());
//     }
//
//     super.onInit();
//   }
//
//   /// 🔄 Clear All Filters
//   Map<String, dynamic> onClearAll() {
//     selectedSubscriptionFilter.value = 0;
//     selectedLevel.clear();
//     selectedRating.clear();
//     selectedSub.value = DropDownData(id: "0", optionName: subscriptionData[0].toLowerCase());
//     listOFSelectedLang.clear();
//     listOfSelectedTeacher.clear();
//     listOFSelectedDuration.clear();
//     listOFSelectedCat.clear();
//     listSelectedDate.clear();
//
//     isCategoryLoading.value = true;
//     isTeacherLoading.value = true;
//     Future.delayed(const Duration(seconds: 1), () {
//       isCategoryLoading.value = false;
//       isTeacherLoading.value = false;
//     });
//
//     return {
//       "category": listOFSelectedCat,
//       "language": listOFSelectedLang,
//       "level": selectedLevel,
//       "duration": listOFSelectedDuration,
//       "rating": selectedRating,
//       "is_free": selectedSub.value,
//       "teacher": listOfSelectedTeacher,
//       "date_filter": listSelectedDate,
//
//     };
//   }
//
//   /// 🔄 Apply Filter
//   Map<String, dynamic> onApply({String? dateFilter}) {
//     if (selectedLevel.any((element) => element.id == "0")) {
//       selectedLevel.removeWhere((element) => element.id == "0");
//     }
//
//     if (selectedRating.any((element) => element.ratingValue == "all")) {
//       selectedRating.removeWhere((element) => element.ratingValue == "all");
//     }
//
//     return {
//       "category": listOFSelectedCat,
//       "level": selectedLevel,
//       "duration": listOFSelectedDuration,
//       "rating": selectedRating,
//       "is_free": selectedSub.value,
//       "teacher": listOfSelectedTeacher,
//       "date_filter": listSelectedDate,
//     };
//   }
//
//   /// ⏱ Date Filter Logic
//   List<Map<String, dynamic>> filterByDateRange(List<Map<String, dynamic>> dataList, String filterType) {
//     final now = DateTime.now();
//     final today = DateTime(now.year, now.month, now.day);
//     final yesterday = today.subtract(Duration(days: 1));
//     final startOfWeek = today.subtract(Duration(days: today.weekday - 1)); // Monday
//     final startOfLastWeek = startOfWeek.subtract(Duration(days: 7));
//     final endOfLastWeek = startOfWeek.subtract(Duration(days: 1));
//     final startOfMonth = DateTime(now.year, now.month, 1);
//
//     return dataList.where((item) {
//       final endDateStr = item['end_datetime'];
//       if (endDateStr == null) return false;
//
//       final endDateTime = DateTime.tryParse(endDateStr);
//       if (endDateTime == null) return false;
//
//       final endDate = DateTime(endDateTime.year, endDateTime.month, endDateTime.day);
//
//       switch (filterType) {
//         case 'today':
//           return endDate == today;
//         case 'yesterday':
//           return endDate == yesterday;
//         case 'last_week':
//           return endDate.isAfter(startOfLastWeek.subtract(Duration(seconds: 1))) &&
//               endDate.isBefore(endOfLastWeek.add(Duration(days: 1)));
//         case 'this_month':
//           return endDate.isAfter(startOfMonth.subtract(Duration(seconds: 1))) &&
//               endDate.month == now.month && endDate.year == now.year;
//         default:
//           return true;
//       }
//     }).toList();
//   }
//
//   /// 🚀 Fetch Categories
//   getAllCategory({String sort = "ASC"}) async {
//     isCategoryLoading.value = true;
//     await courseProvider.getAllCategories(
//       languageId: Get.find<AuthService>().user.value.languageId?.toString() ?? "",
//       searchKeyWord: "",
//       onError: (message, errorMap) {
//         isCategoryLoading.value = false;
//         toastShow(message: message);
//       },
//       onSuccess: (message, json) async {
//         category.AllCategoryModel data = category.AllCategoryModel.fromJson(json!);
//         for (category.Datum? data in data.data ?? []) {
//           categoryList.add(DropDownData(id: data?.id.toString(), optionName: data?.title));
//         }
//         isCategoryLoading.value = false;
//       },
//       sort: sort,
//     );
//   }
//
//   /// 🚀 Fetch Teachers
//   getAllTeachers() async {
//     isTeacherLoading.value = true;
//     await courseProvider.getTeacherData(
//       onError: (message, map) {
//         toastShow(message: message);
//         isTeacherLoading.value = false;
//       },
//       onSuccess: (message, json) {
//         List list = json!['data'];
//         teacherList.value = List.from(list.map((e) => TeacherModel.fromJson(e)));
//         isTeacherLoading.value = false;
//       },
//     );
//   }
// }
//
// /// ⭐ Rating Filter Model
// class RatingDataVal {
//   final String? ratingName;
//   final String? ratingValue;
//
//   RatingDataVal({this.ratingName, this.ratingValue});
// }
//
// /// 👨‍🏫 Teacher filter model extension
// extension TeacherModel on DropDownData {
//   static fromJson(Map<String, dynamic> json) => DropDownData(
//     id: json["id"].toString(),
//     displayName: json['name'],
//     optionName: json['name'],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": int.parse(id!),
//     "name": optionName,
//   };
// }
class ClassesFilterController extends GetxController {
  ClassesFilterController({
    DropDownData? selectedSubscription,
    required List<DropDownData> listOSelectedCat, required this.isPastFilter,
  }) {
    Future.delayed(Duration.zero, () {
      listOFSelectedCat.value = [];
      listOFSelectedCat.addAll(listOSelectedCat);
    });
    selectedSub =
        DropDownData(id: "0", optionName: subscriptionData[0].toLowerCase())
            .obs;
    selectedSub.value = DropDownData(
        id: selectedSubscription?.id ?? "0",
        optionName:
        selectedSubscription?.optionName ?? subscriptionData[0].toLowerCase());

    if (selectedSubscription?.optionName == "free") {
      selectedSubscriptionFilter.value = 1;
    } else if (selectedSubscription?.optionName == "pro") {
      selectedSubscriptionFilter.value = 2;
    } else {
      selectedSubscriptionFilter.value = 0;
    }
    _initDaysList();
    logPrint("selected sub in constructor ${selectedSub.value.optionName}");
  }
  final bool isPastFilter;

  RxList<DropDownData> levelData = Get.find<AuthService>().levelData;
  RxList<DropDownData> selectedLevel = <DropDownData>[].obs;
  RxList<DropDownData> categoryList = <DropDownData>[].obs;
  RxList<DropDownData> durationList = <DropDownData>[
    DropDownData(id: "1", optionName: "15", displayName: "15 Minutes"),
    DropDownData(id: "2", optionName: "30", displayName: "30 Minutes"),
    DropDownData(id: "3", optionName: "45", displayName: "45 Minutes"),
    DropDownData(id: "4", optionName: "60", displayName: "60 Minutes"),
    DropDownData(id: "5", optionName: "90", displayName: "90 Minutes"),
  ].obs;

  RxList<DropDownData> langList = Get.find<RootViewController>().languageData;
  RxList<String> subscriptionData = <String>["All", "Free", "Pro"].obs;
  RxInt selectedSubscriptionFilter = 0.obs;
  RxList<DropDownData> teacherList = <DropDownData>[].obs;
  RxList<DropDownData> listOfSelectedTeacher = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedDuration = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedLang = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedCat = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedDays = <DropDownData>[].obs;
  RxBool isDaysLoading = false.obs;

  // Days list, dynamically set
  RxList<DropDownData> daysList = <DropDownData>[].obs;

  // ✅ New Days Filter



  RxList<RatingDataVal> selectedRating = <RatingDataVal>[
    RatingDataVal(
      ratingName: "All",
      ratingValue: "all",
    ),
  ].obs;

  late Rx<DropDownData> selectedSub;

  RxList<RatingDataVal> ratingData = <RatingDataVal>[
    RatingDataVal(
      ratingName: "All",
      ratingValue: "all",
    ),
    RatingDataVal(
      ratingName: "5 star",
      ratingValue: "5",
    ),
    RatingDataVal(
      ratingName: "4 star",
      ratingValue: "4",
    ),
    RatingDataVal(
      ratingName: "3 star",
      ratingValue: "3",
    ),
    RatingDataVal(
      ratingName: "2 star",
      ratingValue: "2",
    ),
    RatingDataVal(
      ratingName: "1 star",
      ratingValue: "1",
    ),
  ].obs;

  CourseProvider courseProvider = getIt();
  RxBool isCategoryLoading = false.obs;
  RxBool isDataLoading = false.obs;
  RxBool isTeacherLoading = false.obs;

  @override
  void onInit() async {
    getAllCategory();
    if (levelData.isNotEmpty) {
      if (!(levelData.any((element) => element.optionName == "All"))) {
        levelData.insert(0, DropDownData(optionName: "All", id: "0"));
      }
      final classLevel = await Get.find<AuthService>().getClassLevel();
      if (classLevel.isEmpty) {
        selectedLevel.add(
          DropDownData(
              id: Get.find<AuthService>().user.value.level?.id.toString(),
              displayName: null,
              optionName: Get.find<AuthService>()
                  .user
                  .value
                  .level
                  ?.level
                  .toString()
                  .toLowerCase()),
        );
      }

      selectedLevel.addAll(classLevel);
      List<DropDownData> updatedList = [];
      for (var x in selectedLevel) {
        if (!updatedList.any((e) => e.id == x.id)) {
          updatedList.add(x);
        }
      }
      selectedLevel.value = updatedList;
    }

    super.onInit();
  }
  void _initDaysList() {
    daysList.value = isPastFilter
        ? <DropDownData>[
      DropDownData(id: "1", optionName: "Today"),
      DropDownData(id: "2", optionName: "Yesterday"),
      DropDownData(id: "3", optionName: "Last Week"),
      DropDownData(id: "4", optionName: "This Month"),
    ]
        : <DropDownData>[
      DropDownData(id: "1", optionName: "Today"),
      DropDownData(id: "2", optionName: "Tomorrow"),
      DropDownData(id: "3", optionName: "This Week"),
      DropDownData(id: "4", optionName: "This Month"),
    ];
  }
  Map<String, dynamic> onClearAll() {
    selectedSubscriptionFilter.value = 0;
    selectedLevel.clear();
    selectedRating.clear();
    listOFSelectedLang.clear();
    listOfSelectedTeacher.clear();
    listOFSelectedDuration.clear();
    listOFSelectedCat.clear();
    listOFSelectedDays.clear();
    selectedSub.value =
        DropDownData(id: "0", optionName: subscriptionData[0].toLowerCase());
    isCategoryLoading.value = true;
    isTeacherLoading.value = true;
    Future.delayed(const Duration(seconds: 1), () {
      isCategoryLoading.value = false;
      isTeacherLoading.value = false;
    });
    return {
      "category": listOFSelectedCat,
      "language": listOFSelectedLang,
      "level": selectedLevel,
      "duration": listOFSelectedDuration,
      "rating": selectedRating,
      "is_free": selectedSub.value,
      "teacher": listOfSelectedTeacher,
      "days": listOFSelectedDays, // ✅ Return days on clear
    };
  }

  getAllCategory({String sort = "ASC"}) async {
    isCategoryLoading.value = true;
    await courseProvider.getAllCategories(
        languageId: Get.find<AuthService>().user.value.languageId != null
            ? Get.find<AuthService>().user.value.languageId.toString()
            : "",
        searchKeyWord: "",
        onError: (message, errorMap) {
          isCategoryLoading.value = false;
          toastShow(message: message);
        },
        onSuccess: (message, json) async {
          category.AllCategoryModel data =
          category.AllCategoryModel.fromJson(json!);
          for (category.Datum? data in data.data ?? []) {
            categoryList.add(
                DropDownData(id: data?.id.toString(), optionName: data?.title));
          }
          isCategoryLoading.value = false;
        },
        sort: sort);
  }

  getAllTeachers() async {
    isTeacherLoading.value = true;
    await courseProvider.getTeacherData(onError: (message, map) {
      toastShow(message: message);
      isTeacherLoading.value = false;
    }, onSuccess: (message, json) {
      List list = json!['data'];
      teacherList.value = List.from(list.map((e) => TeacherModel.fromJson(e)));
      isTeacherLoading.value = false;
    });
  }
  Map<String, dynamic> onApply() {
    if (selectedLevel.any((element) => element.id == "0")) {
      selectedLevel.removeWhere((element) => element.id == "0");
    }

    if (selectedRating.any((element) => element.ratingValue == "all")) {
      selectedRating.removeWhere((element) => element.ratingValue == "all");
    }

    // final dateRange = getDateRangeForSelectedDay();
    return {
      "category": listOFSelectedCat,
      "level": selectedLevel,
      "duration": listOFSelectedDuration,
      "rating": selectedRating,
      "is_free": selectedSub.value,
      "teacher": listOfSelectedTeacher,
      "days": listOFSelectedDays,
      // "start_datetime": dateRange["start_datetime"],
      // "end_datetime": dateRange["end_datetime"],
    };
  }

}

class RatingDataVal {
  final String? ratingName;
  final String? ratingValue;

  RatingDataVal({this.ratingName, this.ratingValue});
}

extension TeacherModel on DropDownData {
  static fromJson(Map<String, dynamic> json) => DropDownData(
    id: json["id"].toString(),
    displayName: json['name'],
    optionName: json['name'],
  );

  Map<String, dynamic> toJson() => {
    "id": int.parse(id!),
    "name": optionName,
  };
}