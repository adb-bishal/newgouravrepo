import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:stockpathshala_beta/service/utils/Session.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stockpathshala_beta/model/models/common_container_model/common_container_model.dart';
import 'package:stockpathshala_beta/model/models/live_class_model/live_class_model.dart';
import 'package:stockpathshala_beta/model/network_calls/dio_client/get_it_instance.dart';
import 'package:stockpathshala_beta/model/utils/app_constants.dart';
import 'package:stockpathshala_beta/service/utils/object_extension.dart';
import 'package:stockpathshala_beta/view/widgets/button_view/common_button.dart';
import 'package:stockpathshala_beta/view/widgets/circular_indicator/circular_indicator_widget.dart';
import 'package:stockpathshala_beta/view/widgets/log_print/log_print_condition.dart';
import 'package:stockpathshala_beta/view_model/routes/app_pages.dart';
import '../../../../model/network_calls/api_helper/provider_helper/live_provider.dart';
import '../../../../model/services/auth_service.dart';
import '../../../../model/services/pagination.dart';
import '../../../../view/screens/root_view/live_classes_view/live_class_detail/live_class_webview.dart';
import '../../../../view/screens/root_view/live_classes_view/live_classes_view.dart';
import '../../../../view/widgets/toast_view/showtoast.dart';
import '../root_view_controller.dart';

class LiveClassesController extends GetxController {
  LiveProvider liveProvider = getIt();
  Rx<LiveClassModel> liveData = LiveClassModel().obs;
 // RxList<DropDownData> listOFSelectedCat = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedDays = <DropDownData>[].obs;
  // RxList<RatingDataVal> selectedRating = <RatingDataVal>[].obs;
  late Rx<PagingScrollController<CommonDatum>> dataPagingController;
  RxBool isDataLoading = false.obs;
  RxBool isOnTapAllowd = true.obs;
  RxBool isTabValueChange = false.obs;
  RxBool onRegisterWebinar = false.obs;
  RxString serverTime = ''.obs;
  RxList<int> LiveClassTimeDifferences = <int>[].obs; // in seconds
  RxList<int> liveClassDaysLeft = <int>[].obs;
  RxList<Map<String, DateTime>> liveClassTimes = <Map<String, DateTime>>[].obs;
  RxList<int> isRegisterList = <int>[].obs;
  var isStartedClass = <int, bool>{}.obs;   // Track start state per tile
  final Map<int, Timer?> _timers = {};      // Timer references for each tile
  var liveClassIndexTimers = <int, int>{}.obs;  // Track countdown for each tile



  RxInt start = 0.obs;
  RxString time = "".obs;
  Timer? timer;

  RxBool timerTrue = false.obs;

  RxInt lastVisitedPage = 1.obs;

  RxString searchKey = "".obs;
  RxBool isClearLoading = false.obs;
  RxInt countValue = 0.obs;
  late TabController tabController;
  RxList<Tab> tabs = <Tab>[
    const Tab(text: 'LIVE Webinars'),
    const Tab(text: 'Recordings'),
  ].obs;
  Rx<TextEditingController> searchController = TextEditingController().obs;
// RxList<DropDownData> listOFSelectedLang = <DropDownData>[].obs;
  RxList<DropDownData> listOFSelectedCat = <DropDownData>[].obs;
  RxList<DropDownData> selectedLevel = <DropDownData>[].obs;
  // Rx<DropDownData>     selectedRating = DropDownData().obs;
  Rx<DropDownData> selectedSub = DropDownData().obs;
  BuildContext? context;
  String token = Get.find<AuthService>().getUserToken();
  Dio _dio = Dio();

  RxList<DropDownData> listOFSelectedDuration = <DropDownData>[].obs;
  final rootViewController = Get.find<RootViewController>();

  @override
  void onInit() async {
    dataPagingController = PagingScrollController<CommonDatum>(
        onLoadMore: (int page, int totalItemsCount) async {
      await getLiveData(pageNo: page);
    }, getStartPage: () {
      return 1; // Use the last visited page
    }, getThreshold: () {
      return 0;
    }).obs;

    // Fetch data for the last visited page
    await getLiveData(pageNo: 1);
    super.onInit();
  }

  void showTooltiRegesterClass() async {
    if (dataPagingController.value.list.isNotEmpty) {
      final firstClass = dataPagingController.value.list.first;
      if (firstClass.isRegister == 0) {
        final toolTipList = await Get.find<AuthService>().getTrainingTooltips();
        if (!toolTipList.contains('registerClass')) {
          Future.delayed(const Duration(seconds: 1), () {
            rootViewController.toolTipcontroller.start(3);
          });
        }
      }
      showJoinToolTip();
    }
  }

  void showJoinToolTip() async {
    final now = DateTime.now();
    final firstClass = dataPagingController.value.list.first;
    if (((!((firstClass.startTime ?? DateTime.now()) > now)) &&
        firstClass.isRegister == 1)) {
      final toolTipList = await Get.find<AuthService>().getTrainingTooltips();
      if (!toolTipList.contains('joinLiveClass')) {
        Future.delayed(const Duration(seconds: 1), () {
          rootViewController.toolTipcontroller.start(3);
        });
      }
    }
  }

  onClassSearch(val) {
    EasyDebounce.debounce(
        countValue.value.toString(), const Duration(milliseconds: 1000),
        () async {
      getLiveData(pageNo: 1, searchKeyWord: val);
      countValue.value++;
    });
  }

  Future<void> onRefresh() async {
    getLiveData(pageNo: 1, searchKeyWord: searchKey.value);
    Get.find<RootViewController>().getProfile();
  }

  void tabChange() {
    getLiveData(pageNo: 1, searchKeyWord: searchKey.value);
  }

  Future<void> getLiveData({
    required int pageNo,
    String? searchKeyWord,
    String? categoryId,
    String? langId,
    String? levelId,
    String? duration,
    String? rating,
    String? dateFilter,


    String? subscriptionLevel,
    bool callFromRegister = false,


  }) async {
    logPrint("getDateFilterDatasb past9 $categoryId");
    print("getDateFilterDatasb past2  ${dateFilter}");
    searchKey.value = searchKeyWord ?? "";
    // lastVisitedPage.value = pageNo; // Store last visited page
    if (pageNo != 1) {
      dataPagingController.value.isDataLoading.value = true;
    } else {
      if (callFromRegister) {
        dataPagingController.value.isDataLoading.value = true;
      } else {
        dataPagingController.value.reset();
        isDataLoading.value = true;
      }
    }
    await liveProvider.getLiveData(
        onError: (message, errorMap) {
          toastShow(message: message);
          isDataLoading.value = false;
          dataPagingController.value.isDataLoading.value = false;
        },
        onSuccess: (message, json) {
          print("Date Filter Applied: $dateFilter");
          if (pageNo == 1) {
            LiveClassTimeDifferences.clear(); // Clear only for the first page
            liveClassTimes.clear();
            isRegisterList.clear();
            liveClassIndexTimers.clear();
            isStartedClass.clear();
          }
          if (isTabValueChange.value == true) {
            liveData.value = LiveClassModel.fromJson(json!);
            print('drferver ${liveData.value.cardUi?.cardBgColor}');
            if (liveData.value.data?.data?.isNotEmpty ?? false) {
              if (callFromRegister) {
                dataPagingController.value.list.clear();
              }
              dataPagingController.value.list.addAll(
                List<CommonDatum>.from(
                  liveData.value.data!.data!.map(
                    (x) => CommonDatum.fromJson(
                      x.toJson(),
                    ),
                  ),
                ),
              );
            } else {
              dataPagingController.value.isDataLoading.value = false;
            }

            if (isTabValueChange.value == true) {
              tabController.index = 1;
              isTabValueChange.value = false;
            } else {
              print("klhjjfklashfk");
              tabController.index = 0;
            }

            isDataLoading.value = false;
          } else {
            liveData.value = LiveClassModel.fromJson(json!);

            serverTime.value = liveData.value.serverTime!;
            List<dynamic> classes = json['data']['data'];

            logPrint("class list dfsdf: ${json['data']['data']}");

            print("serverTime is : ${serverTime.value}");

            // Convert serverTime to DateTime
            DateTime serverDateTime = DateTime.parse(serverTime.value);

            for (var liveClass in classes) {
              String startTimeString = liveClass['start_datetime'];
              String endTimeString = liveClass['end_datetime'];

              try {
                DateTime startTime = DateTime.parse(startTimeString);
                DateTime endTime = DateTime.parse(endTimeString);

                Duration timeDifference = startTime.difference(serverDateTime);

                // Append the time difference to the list instead of clearing it
                LiveClassTimeDifferences.add(timeDifference.inSeconds);

                // Add start and end time to the list
                liveClassTimes.add({
                  'startTime': startTime,
                  'endTime': endTime,
                });

                // Start countdown if needed
                startCountdownForClass(LiveClassTimeDifferences.length - 1);
              } catch (e) {
                print("Error parsing date strings: $e");
              }
            }

            // for (int i = 0; i < classes.length; i++) {
            //   String startTimeString = classes[i]['start_datetime'];
            //   String endTimeString = classes[i]['end_datetime'];

            //   try {
            //     DateTime startTime = DateTime.parse(startTimeString);
            //     DateTime endTime = DateTime.parse(endTimeString);

            //     print("strattime is kkkk: ${startTime}");

            //     // Calculate the difference between the current time and start time
            //     Duration timeDifference = startTime.difference(serverDateTime);
            //     LiveClassTimeDifferences.add(
            //         timeDifference.inSeconds); // store difference in seconds

            //     // Add the start and end times as a map to the mentorshipClassTimes list
            //     liveClassTimes.add({
            //       'startTime': startTime,
            //       'endTime': endTime,
            //     });

            //     // Check if the time difference is less than 3600 seconds and start countdown if true
            //     if (timeDifference.inSeconds <= 86400 ||
            //         timeDifference.inSeconds >= 86400) {
            //       startCountdownForClass(i);

            //       // Start countdown for this class
            //     }
            //   } catch (e) {
            //     print("Error parsing date strings: $e");
            //   }
            // }

            // Print the liveClassTimes list for verification
            print('live Class Times:');
            liveClassTimes.forEach((classTime) {
              print(
                  'Start Time: ${classTime['startTime']}, End Time: ${classTime['endTime']}');
            });

// Print the LiveClassTimeDifferences list for verification
            print('Live Class Time Differences (in seconds):');
            LiveClassTimeDifferences.forEach((timeDiff) {
              print('Time Difference: $timeDiff seconds');
            });

            // Clear existing data in the list
            // isRegisterList.clear();

            // Iterate over the classes and extract is_register values
            for (var liveClass in classes) {
              try {
                int isRegisterValue = liveClass['is_register'] ?? 0;
                isRegisterList.add(isRegisterValue);

                // String isClassStatusValue = mentorshipClass['class_status'] ?? 0;
                // isClassStatusList.add(isClassStatusValue);
              } catch (e) {
                print("Error extracting is_register: $e");
              }
            }

            print('is Register value :');
            print('is Register value : $isRegisterList');
            isDataLoading.value = false;

            if (liveData.value.data?.data?.isNotEmpty ?? false) {
              if (callFromRegister) {
                dataPagingController.value.list.clear();
              }
              dataPagingController.value.list.addAll(
                List<CommonDatum>.from(
                  liveData.value.data!.data!.map(
                    (x) => CommonDatum.fromJson(
                      x.toJson(),
                    ),
                  ),
                ),
              );
            } else {
              dataPagingController.value.isDataLoading.value = false;
            }
          }
        },
        pageNo: pageNo,
        dateFilter: dateFilter,
        categoryId: listOFSelectedCat
            .map((element) => element.id)
            .toList()
            .toString()
            .replaceAll("[", "")
            .replaceAll("]", "")
            .removeAllWhitespace,
        langId: langId,
        levelId: selectedLevel
            .map((element) => element.id)
            .toList()
            .toString()
            .replaceAll("[", "")
            .replaceAll("]", "")
            .removeAllWhitespace,
        duration: listOFSelectedDuration
            .map((element) => element.optionName)
            .toList()
            .toString()
            .replaceAll("[", "")
            .replaceAll("]", "")
            .removeAllWhitespace,
        rating: rating,
        subscriptionLevel: selectedSub.value.optionName,
        searchKeyWord: searchKey.value);
    if (pageNo != 1) {
      // dataPagingController.value.isDataLoading.value = false;
    }
  }

  void startCountdownForClass(int classIndex) {
    int timeDifference = LiveClassTimeDifferences[classIndex];

    print("Time Difference: $timeDifference");

    if (timeDifference > 86400 * 2) {
      time.value = "Registered";
      liveClassIndexTimers[classIndex] = -1; // "Registered" state
      isStartedClass[classIndex] = false;
    } else if (timeDifference < 86400 * 2) {
      // Convert time difference into days
      int days = (timeDifference / 86400).floor();
      print("days block is ::: ${days}");

      time.value = "$days ${days == 1 ? 'day' : 'days'}";
      liveClassIndexTimers[classIndex] = days;
      isStartedClass[classIndex] = false;
      timerTrue.value = false;
    } else {
      // If less than 24 hours, start the countdown

      print("days block is :::");
      // start.value = timeDifference;
      liveClassIndexTimers[classIndex] = timeDifference;
      isStartedClass[classIndex] = false;
      time.value = "${start.value}s";

      // Cancel any existing timer
      // timer?.cancel();
      _timers[classIndex]?.cancel();
      // timer = Timer.periodic(Duration(seconds: 1), (Timer timer) {
      _timers[classIndex] = Timer.periodic(Duration(seconds: 1), (Timer timer) {

        // if (start.value <= 0) {
        if (liveClassIndexTimers[classIndex]! <= 0) {
          timer.cancel();
          isStartedClass[classIndex] = true; // Countdown has ended
          timerTrue.value = true;


        } else {
          // start.value--;
          liveClassIndexTimers[classIndex] = liveClassIndexTimers[classIndex]! - 1;

          time.value = "${start.value}s";
          // isStartedClass.value = false;
          // timerTrue.value = false;
        }
      });
    }
  }

  Future<void> onJoinLiveClass(
    String liveClassId,
    int index, {
    bool isUpdateScreen = false,
    String? liveClassTitle,
  }) async {
    Get.dialog(const CommonCircularIndicator());
    await postVideoJoinStatus(false, index,
        liveClassId: liveClassId, isUpdateScreen: isUpdateScreen);
    isDataLoading.value = false;
  }

  Future<void> onRegisterForLiveClass(int id, String type) async {
    onRegisterWebinar.value = true;
    String baseUrl =
        '${AppConstants.instance.baseUrl}live_classes'; // Your actual base URL

    try {
      // Prepare the body and headers
      var body = {
        'live_class_id': id,
        'type': type,
      };

      // Send the POST request
      final response = await _dio.post(
        baseUrl,
        data: jsonEncode(body), // Use jsonEncode to send the body as JSON
        options: Options(
          headers: {
            'Authorization': 'Bearer $token', // Add the token here
            'Content-Type':
                'application/json', // Ensure the Content-Type is application/json
          },
        ),
      );

      // Handle the response
      if (response.statusCode == 200) {
        onRegisterWebinar.value = false;
        // print('Response received successfully.');
        // // Assuming participant is a reactive variable
        // participant.value = response.data['data']['participant_link'];

        // print('Participant Link: ${participant.value}');

        // SharedPreferences mentorId = await SharedPreferences.getInstance();
        // String mentorIdValue = mentorId.getString('mId') ?? '';
        // Get.back();
        // Get.toNamed(
        //   Routes.mentorshipDetail(
        //     id: mentorIdValue,
        //   ),
        //   arguments: {
        //     'id': mentorIdValue,
        //   },
        // );

        // onReload();

        // print("paymenteddas");
        // fetchMentorshipData(mentorIdValue);
        update();
        // You can use the participant link here or navigate to a different screen
      } else {
        onRegisterWebinar.value = false;

        print('Error: ${response.data['message']}');
      }
    } catch (e) {
      onRegisterWebinar.value = false;

      print('Error: $e');
    }
  }

  Future<void> onRegister(
    String liveClassId,
    int index, {
    bool isUpdateScreen = false,
  }) async {
    print('srfewrfwer');
    Get.find<AuthService>().user.value.liveCount =
        0; //This resets the liveCount property of the user to 0
    isDataLoading.value = false;
    await postVideoJoinStatus(true, index,
        liveClassId: liveClassId, isUpdateScreen: isUpdateScreen);
    Get.find<RootViewController>().getProfile();
    isDataLoading.value = false;
  }

  Future<void> postVideoJoinStatus(
    bool isRegister,
    int index, {
    required String liveClassId,
    bool isUpdateScreen = false,
    String? liveClassTitle,
  }) async {
    await liveProvider.postVideoJoinStatus(
        onError: (message, errorMap) {
          // logPrint("on error method called :::" + json.toString());
          // onRegisterPopUp(errorMap);
        },
        onSuccess: (message, json) async {
          logPrint("json is ${json}");
          if (json?['status'] == true &&
              (json?['data'].containsKey('popup_data') ?? false)) {
            logPrint(" status is ${json?['status']}");
            logPrint(" status is ${json?['status']}");
            onRegisterPopUp(json);
          } else {
            if (isRegister) {
              dataPagingController.value.list[index].isLoading = false;
              dataPagingController.value.list[index].isRegister = 1;
              isOnTapAllowd.value = true;
              isDataLoading.value = false;
              // update();
              // getLiveData(pageNo: 1);
              // dataPagingController.value.list[index].

              // unawaited(
              //     getLiveData(pageNo: 1, callFromRegister: isUpdateScreen));
              onRegisterPopUp(json);
            } else {
              Get.back();
              if (json?['data']['participant_link'] != null) {
                Navigator.push(
                  Get.context!,
                  MaterialPageRoute(
                    builder: (context) => LiveClassLaunch(
                      title: liveClassTitle ?? '',
                      url: json?['data']['participant_link'],
                    ),
                  ),
                );
              }
            }
          }
        },
        onComplete: () {
          // Handle completion, equivalent to onComplete
          logPrint("on Complete method called :::");
          dataPagingController.value.isDataLoading.value = false;
          isOnTapAllowd.value = true;
          isDataLoading.value = false;
          update();
          // getLiveData(pageNo: 1);
          // unawaited(getLiveData(pageNo: 1, callFromRegister: isUpdateScreen));
        },
        mapData: {
          "live_class_id": liveClassId,
          "type": isRegister ? "register" : "join",
          "device": Platform.isIOS ? "ios" : "android"
        });
  }

  onRegisterPopUp(json) {
    // emailController.text = "Enter your name";
    // bool isName = Get.find<AuthService>().user.value.name == null;
    logPrint("onRegister json value is ${json.toString()}");
    final title = json?['data']['popup_data']['title'] ?? 'limit reached';
    logPrint(" Title of the popUP is ${title}");
    final imageUrl = json?['data']['popup_data']['image_url'] ?? '';
    final description = json?['data']['popup_data']['description'] ?? 'limit';
    final titleColor = json?['data']['popup_data']['title_color'] ?? '#000000';
    final dismissButton =
        json?['data']['popup_data']['dismiss_button'] ?? 'default';
    final descriptionColor =
        json?['data']['popup_data']['description_color'] ?? '#000000';
    final dismissButtonColor =
        json?['data']['popup_data']['dismiss_button_color'] ?? '#000000';
    final dismissBtnTextColor =
        json?['data']['popup_data']['dismiss_btn_text_color'] ?? '#000000';

    int time = -1;
    Timer(Duration(seconds: time), () {
      Get.bottomSheet(
        // showDialog(
        //     context: Get.context!,
        //     builder: (BuildContext context) {
        //       return WillPopScope(
        //         onWillPop: (() async => true),
        //         child: Dialog(
        //             shape: RoundedRectangleBorder(
        //               borderRadius: BorderRadius.circular(16.0),
        //             ),
        // child: SizedBox(
        // height:
        // isName ?
        // (Get.height / 2.5) + 16,
        //  : (Get.height / 2.75),
        Container(
          padding: EdgeInsets.all(15),
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25.0),
              topRight: Radius.circular(25.0),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(),
                    IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: const Icon(Icons.close))
                  ],
                ),
                Image.network(
                  imageUrl,
                  height: 100,
                ),
                Text(
                  title,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color:
                          Color(int.parse(titleColor.replaceAll('#', '0xff')))),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 8.0,
                    vertical: 2,
                  ),
                  child: Text(
                    description.replaceAll(RegExp(r'<[^>]*>'), ''),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 14,
                        color: Color(int.parse(
                            descriptionColor.replaceAll('#', '0xff')))),
                  ),
                ),
                // isName?
                const SizedBox(
                  height: 14,
                ),
                // : const SizedBox(),
                // isName
                //     ? Padding(
                //         padding: const EdgeInsets.symmetric(
                //             horizontal: 12, vertical: 0),
                //         child: Obx(
                //           () => Form(
                //             key: signInFormKey,
                //             child: CommonTextField(
                //               showEdit: false,
                //               isSpace: true,
                //               isTrailPopUp: true,
                //               readOnly: isLoading.value,
                //               onTap: () {
                //                 emailController.text = "";
                //               },
                //               isLogin: false,
                //               isHint: false,
                //               controller: emailController,
                //               keyboardType: TextInputType.text,
                //               validator: (value) {
                //                 if (value == "Enter your name") {
                //                   emailError.value =
                //                       StringResource.nameInvalidError;
                //                   return "";
                //                 } else if (value!.length <= 3) {
                //                   emailError.value =
                //                       StringResource.nameInvalidError;
                //                   return "";
                //                 } else {
                //                   emailError.value = "";
                //                   return null;
                //                 }
                //               },
                //               errorText: emailError.value,
                //             ),
                //           ),
                //         ),
                //       )
                //     : Container(),
                const SizedBox(
                  height: 12,
                ),
                SizedBox(
                  width: 120,
                  height: 35,
                  child: CommonButton(
                      color: Color(int.parse(
                          dismissButtonColor.replaceAll('#', '0xff'))),
                      text: dismissButton,
                      loading: false,
                      onPressed: () {
                        Get.back();
                        Get.toNamed(Routes.subscriptionView);
                      }),
                )
              ],
            ),
          ),
        ),
        // )),
        // );
        // },
        barrierColor: Colors.black.withOpacity(0.5), // Optional
        isDismissible: true, // Optional
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
        ), // Optional
        enableDrag: true, // Optional
        // barrierDismissible: false
        // );
      );
    });
  }
}
