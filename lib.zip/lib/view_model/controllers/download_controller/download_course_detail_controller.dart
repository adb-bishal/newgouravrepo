import 'package:get/get.dart';

class DownloadCourseController extends GetxController{

}