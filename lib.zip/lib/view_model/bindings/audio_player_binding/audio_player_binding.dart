import 'package:get/get.dart';

class AudioPlayerBinding extends Bindings{
  @override
  void dependencies() {
   //Get.lazyPut<AudioPlayerController>(() => AudioPlayerController());
  }

}