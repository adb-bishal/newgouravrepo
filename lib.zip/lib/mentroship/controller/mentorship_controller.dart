// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:dio/dio.dart';
// import 'package:stockpathshala_beta/mentroship/model/mentorList_model.dart';
// import 'package:stockpathshala_beta/mentroship/model/mentorshipCardList_model.dart';
// import 'package:stockpathshala_beta/mentroship/model/mentorship_model.dart';
// import 'package:stockpathshala_beta/model/utils/app_constants.dart';
// import 'package:stockpathshala_beta/model/utils/color_resource.dart';
//
// import '../../service/floor/clientService.dart';
// import '../../view_model/controllers/root_view_controller/root_view_controller.dart';
//
// class MentorshipController extends GetxController
//     with GetSingleTickerProviderStateMixin {
//   // Reactive variables
//   final Rx<MentorshipModel?> mentorshipData = Rx<MentorshipModel?>(null);
//   final RxBool isLoading = false.obs;
//   final RxList<MentorCardData> mentorshipList = <MentorCardData>[].obs;
//   final RxList<MentorData> mentorList = <MentorData>[].obs;
//   final RxBool isMentorListLoading = false.obs;
//   final RxString errorMessage = ''.obs;
//   final RxBool isListLoading = false.obs;
//   final RxInt currentPage = 1.obs;
//   final RxInt lastPage = 1.obs;
//   final RxBool hasMoreData = true.obs;
//
//   static String basesUrl = '${AppConstants.instance.baseUrl}mentorship';
//
//   // Base URLs
// //   static const String betaBaseUrl = 'https://sp-backend-beta.stockpathshala.com/api/v1/mentorship';
// //   static const String internalBaseUrl = 'https://internal.stockpathshala.in/api/v1/mentorship/';
// //
// // // API URLs for Beta
// //   static const String apiUrl = '${betaBaseUrl}/list_ui';
// //   static const String urlMentor = '${betaBaseUrl}/mentor_list';
// //   static const String baseUrl = betaBaseUrl;
//
//   static String apiUrl = "${basesUrl}/list_ui";
//   static String urlMentor = "${basesUrl}/mentor_list";
//   var baseUrl = "${basesUrl}?type=running".obs;
//
// // API URLs for Internal
// //   static const String apiUrl = '${internalBaseUrl}list_ui';
// //   static const String urlMentor = '${internalBaseUrl}mentor_list';
// //   static const String baseUrl = internalBaseUrl;
//
//   final Dio _dio = Dio(); // Initialize Dio instance
//
//   TabController? tabController;
//   var listHeight = 1000.0.obs; // Default height
//
//   @override
//   void onInit() {
//     super.onInit();
//     tabController = TabController(length: 3, vsync: this);
//     // tabController?.addListener(onTabChanged);
//     tabController?.addListener(() {
//       onTabChanged();
//       updateListHeight(); // Update height when tab changes
//     });
//     getMentorshipData();
//     getCardDetails();
//
//     fetchMentorList();
//     // getCardDetails();
//
//     fetchData(type: 'running');
//     fetchData(type: 'upcoming');
//     fetchData(type: 'past');
//
//     setStatusBarAppearance();
//
//     // updateListHeight();
//   }
//
//   void updateListHeight() {
//     var currentList = tabController?.index == 0
//         ? runningList
//         : tabController?.index == 1
//             ? upcomingList
//             : pastList;
//     listHeight.value =
//         (currentList.length * 500).toDouble(); // Adjust height dynamically
//   }
//
//   Future<void> onRefresh() async {
//     if (tabController?.index == 0) {
//        fetchData(type: 'running');
//     } else if (tabController?.index == 1) {
//        fetchData(type: 'upcoming');
//     } else if (tabController?.index == 2) {
//       fetchData(type: 'past');
//     }
//
//     getCardDetails();
//     getMentorshipData();
//     fetchMentorList();
//   }
//
//   void setStatusBarAppearance() {
//     SystemChrome.setSystemUIOverlayStyle(
//       SystemUiOverlayStyle(
//         statusBarIconBrightness: Brightness.light,
//         statusBarColor: ColorResource
//             .primaryColor, // Set to transparent or any color you prefer
//       ),
//     );
//   }
//
//   // Base URLs
//   static String upcomingBaseUrl = "${basesUrl}?type=upcoming";
//   static String pastBaseUrl = "${basesUrl}?type=past";
//   static String runningBaseUrl = "${basesUrl}?type=running";
//
//   // Reactive variables for upcoming data
//   final RxList<MentorCardData> upcomingList = <MentorCardData>[].obs;
//   final RxInt upcomingCurrentPage = 1.obs;
//   final RxInt upcomingLastPage = 1.obs;
//   final RxBool upcomingHasMoreData = true.obs;
//   final RxBool isUpcomingLoading = false.obs;
//
//   // Reactive variables for past data
//   final RxList<MentorCardData> pastList = <MentorCardData>[].obs;
//   final RxInt pastCurrentPage = 1.obs;
//   final RxInt pastLastPage = 1.obs;
//   final RxBool pastHasMoreData = true.obs;
//   final RxBool isPastLoading = false.obs;
//
//   // Reactive variables for running data
//   final RxList<MentorCardData> runningList = <MentorCardData>[].obs;
//   final RxInt runningCurrentPage = 1.obs;
//   final RxInt runningLastPage = 1.obs;
//   final RxBool runningHasMoreData = true.obs;
//   final RxBool isRunningLoading = false.obs;
//
//   void onTabChanged() {
//     if (tabController?.index == 0) {
//       if (runningList.isEmpty) fetchData(type: 'running');
//     } else if (tabController?.index == 1) {
//       if (upcomingList.isEmpty) fetchData(type: 'upcoming');
//     } else if (tabController?.index == 2) {
//       if (pastList.isEmpty) fetchData(type: 'past');
//     }
//   }
//
//   Future<void> fetchData(
//       {required String type, bool isPagination = false}) async {
//     if (type == 'upcoming') {
//       if (isUpcomingLoading.value ||
//           (isPagination && !upcomingHasMoreData.value)) return;
//
//       isUpcomingLoading.value = true;
//
//       try {
//         final response = await _dio.get(
//           upcomingBaseUrl,
//           queryParameters: {
//             "limit": 8,
//             "page": upcomingCurrentPage.value,
//           },
//         );
//
//         if (response.statusCode == 200) {
//           final mentorshipResponse = MentorshipCardList.fromJson(response.data);
//           upcomingLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;
//           print('dfvvdfvc${mentorshipResponse.data}');
//
//           if (mentorshipResponse.data != null) {
//             if (isPagination) {
//               upcomingList.addAll(mentorshipResponse.data!);
//               print('dfvdf $upcomingList');
//             } else {
//               upcomingList.value = mentorshipResponse.data!;
//             }
//           }
//           updateListHeight(); // Update height when tab changes
//
//           upcomingHasMoreData.value =
//               upcomingCurrentPage.value < upcomingLastPage.value;
//         }
//       } catch (e) {
//         // Handle error
//       } finally {
//         isUpcomingLoading.value = false;
//       }
//     } else if (type == 'past') {
//       if (isPastLoading.value || (isPagination && !pastHasMoreData.value))
//         return;
//
//       isPastLoading.value = true;
//
//       try {
//         final response = await _dio.get(
//           pastBaseUrl,
//           queryParameters: {
//             "limit": 8,
//             "page": pastCurrentPage.value,
//           },
//         );
//
//         if (response.statusCode == 200) {
//           print('csdvsdv');
//           final mentorshipResponse = MentorshipCardList.fromJson(response.data);
//           pastLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;
//
//           if (mentorshipResponse.data != null) {
//             if (isPagination) {
//               pastList.addAll(mentorshipResponse.data!);
//             } else {
//               pastList.value = mentorshipResponse.data!;
//               print('dfvdf $pastList');
//             }
//           }
//
//           pastHasMoreData.value = pastCurrentPage.value < pastLastPage.value;
//         }
//       } catch (e) {
//         // Handle error
//       } finally {
//         isPastLoading.value = false;
//       }
//     } else if (type == 'running') {
//       if (isRunningLoading.value || (isPagination && !runningHasMoreData.value))
//         return;
//
//       isRunningLoading.value = true;
//
//       try {
//         final response = await _dio.get(
//           runningBaseUrl,
//           queryParameters: {
//             "limit": 8,
//             "page": runningCurrentPage.value,
//           },
//         );
//
//         if (response.statusCode == 200) {
//           print('csdvsdv');
//           final mentorshipResponse = MentorshipCardList.fromJson(response.data);
//           runningLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;
//
//           if (mentorshipResponse.data != null) {
//             if (isPagination) {
//               runningList.addAll(mentorshipResponse.data!);
//             } else {
//               runningList.value = mentorshipResponse.data!;
//               print('dfvdf $runningList');
//             }
//           }
//
//           runningHasMoreData.value =
//               runningCurrentPage.value < runningLastPage.value;
//         }
//       } catch (e) {
//         // Handle error
//       } finally {
//         isRunningLoading.value = false;
//       }
//     }
//   }
//
//   // void loadMore() {
//   //   if (hasMoreData.value && !isListLoading.value) {
//   //     currentPage.value++;
//   //     getCardDetails(isPagination: true);
//   //   }
//   // }
//
//   void loadMore(String type) {
//     if (type == 'upcoming' &&
//         upcomingHasMoreData.value &&
//         !isUpcomingLoading.value) {
//       upcomingCurrentPage.value++;
//       fetchData(type: 'upcoming', isPagination: true);
//     } else if (type == 'past' &&
//         pastHasMoreData.value &&
//         !isPastLoading.value) {
//       pastCurrentPage.value++;
//       fetchData(type: 'past', isPagination: true);
//     } else if (type == 'running' &&
//         runningHasMoreData.value &&
//         !isRunningLoading.value) {
//       runningCurrentPage.value++;
//       fetchData(type: 'running', isPagination: true);
//     }
//   }
//
//   // Fetch main mentorship data
//   Future<void> getMentorshipData() async {
//     try {
//       isLoading.value = true;
//       final response = await _dio.get(apiUrl);
//
//       if (response.statusCode == 200) {
//         mentorshipData.value = MentorshipModel.fromJson(response.data);
//
//       } else {
//         // Get.snackbar(
//         //   "Error",
//         //   "Failed to load data. Status code: ${response.statusCode}",
//         // );
//       }
//     } catch (e) {
//       // Get.snackbar("Error", "An error occurred: $e");
//     } finally {}
//   }
//
//   // Fetch paginated mentorship list
//   Future<void> getCardDetails({bool isPagination = false}) async {
//     if (isListLoading.value || (!hasMoreData.value && isPagination)) return;
//
//     isListLoading.value = true;
//
//     try {
//       final response = await _dio.get(
//         baseUrl.value,
//         queryParameters: {
//           "limit": 8,
//           // "typ": "past",
//           "page": currentPage.value,
//         },
//       );
//
//       if (response.statusCode == 200) {
//         final mentorshipResponse = MentorshipCardList.fromJson(response.data);
//
//         lastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;
//
//         if (mentorshipResponse.data != null) {
//           if (isPagination) {
//             mentorshipList.addAll(mentorshipResponse.data!);
//             print('dfvcdf $mentorList');
//           } else {
//             print('dfvcdf $mentorList');
//
//             mentorshipList.value = mentorshipResponse.data!;
//             print("mentorship data is :: ${mentorshipList.value.first.seatsLeft}");
//           }
//         }
//
//         hasMoreData.value = currentPage.value < lastPage.value;
//       } else {
//         // Get.snackbar(
//         //   "Error",
//         //   "Failed to fetch data. Status code: ${response.statusCode}",
//         // );
//       }
//     } catch (e) {
//       // Get.snackbar("Error", "An error occurred: $e");
//     } finally {
//       isListLoading.value = false;
//     }
//   }
//
//   // Load more data for pagination
//   // void loadMore() {
//   //   if (hasMoreData.value && !isListLoading.value) {
//   //     currentPage.value++;
//   //     getCardDetails(isPagination: true);
//   //   }
//   // }
//
//   // Fetch mentor list data
//   Future<void> fetchMentorList() async {
//     if (isMentorListLoading.value) return;
//
//     isMentorListLoading.value = true;
//
//     try {
//       final response = await _dio.get(urlMentor);
//
//       if (response.statusCode == 200) {
//         final jsonResponse = response.data;
//         final MentorList mentorListData = MentorList.fromJson(jsonResponse);
//
//         mentorList.value = mentorListData.data;
//         isLoading.value = false;
//       } else {
//         errorMessage.value =
//             "Failed to fetch data. Status code: ${response.statusCode}";
//         // Get.snackbar("Error", errorMessage.value);
//       }
//     } catch (e) {
//       errorMessage.value = "An error occurred: $e";
//       // Get.snackbar("Error", errorMessage.value);
//     } finally {
//       isMentorListLoading.value = false;
//     }
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:stockpathshala_beta/mentroship/model/mentorList_model.dart';
import 'package:stockpathshala_beta/mentroship/model/mentorshipCardList_model.dart';
import 'package:stockpathshala_beta/mentroship/model/mentorship_model.dart';
import 'package:stockpathshala_beta/model/utils/app_constants.dart';
import 'package:stockpathshala_beta/model/utils/color_resource.dart';

import '../../service/floor/clientService.dart';
import '../../view_model/controllers/root_view_controller/root_view_controller.dart';

class MentorshipController extends GetxController
    with GetSingleTickerProviderStateMixin {
  final Rx<MentorshipModel?> mentorshipData = Rx<MentorshipModel?>(null);
  final RxBool isLoading = false.obs;
  final RxList<MentorCardData> mentorshipList = <MentorCardData>[].obs;
  final RxList<MentorData> mentorList = <MentorData>[].obs;
  final RxBool isMentorListLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxBool isListLoading = false.obs;
  final RxInt currentPage = 1.obs;
  final RxInt lastPage = 1.obs;
  final RxBool hasMoreData = true.obs;

  static String basesUrl = '${AppConstants.instance.baseUrl}mentorship';
  static String apiUrl = "${basesUrl}/list_ui";
  static String urlMentor = "${basesUrl}/mentor_list";
  var baseUrl = "${basesUrl}?type=running".obs;

  final Dio _dio = Dio();

  TabController? tabController;
  var listHeight = 1000.0.obs;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 3, vsync: this);
    tabController?.addListener(() {
      onTabChanged();
      updateListHeight();
    });

    getMentorshipData();
    getCardDetails();
    fetchMentorList();

    // ✅ Wait for running data to load then update list height
    fetchData(type: 'running').then((_) {
      updateListHeight();
    });

    // Optional preload
    fetchData(type: 'upcoming');
    fetchData(type: 'past');

    setStatusBarAppearance();
  }

  void updateListHeight() {
    var currentList = tabController?.index == 0
        ? runningList
        : tabController?.index == 1
        ? upcomingList
        : pastList;
    listHeight.value = (currentList.length * 510).toDouble();
  }

  Future<void> onRefresh() async {
    if (tabController?.index == 0) {
      fetchData(type: 'running');
    } else if (tabController?.index == 1) {
      fetchData(type: 'upcoming');
    } else if (tabController?.index == 2) {
      fetchData(type: 'past');
    }

    getCardDetails();
    getMentorshipData();
    fetchMentorList();
  }

  void setStatusBarAppearance() {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.light,
        statusBarColor: ColorResource.primaryColor,
      ),
    );
  }

  static String upcomingBaseUrl = "${basesUrl}?type=upcoming";
  static String pastBaseUrl = "${basesUrl}?type=past";
  static String runningBaseUrl = "${basesUrl}?type=running";

  final RxList<MentorCardData> upcomingList = <MentorCardData>[].obs;
  final RxInt upcomingCurrentPage = 1.obs;
  final RxInt upcomingLastPage = 1.obs;
  final RxBool upcomingHasMoreData = true.obs;
  final RxBool isUpcomingLoading = false.obs;

  final RxList<MentorCardData> pastList = <MentorCardData>[].obs;
  final RxInt pastCurrentPage = 1.obs;
  final RxInt pastLastPage = 1.obs;
  final RxBool pastHasMoreData = true.obs;
  final RxBool isPastLoading = false.obs;

  final RxList<MentorCardData> runningList = <MentorCardData>[].obs;
  final RxInt runningCurrentPage = 1.obs;
  final RxInt runningLastPage = 1.obs;
  final RxBool runningHasMoreData = true.obs;
  final RxBool isRunningLoading = false.obs;

  void onTabChanged() {
    if (tabController?.index == 0 && runningList.isEmpty) {
      fetchData(type: 'running');
    } else if (tabController?.index == 1 && upcomingList.isEmpty) {
      fetchData(type: 'upcoming');
    } else if (tabController?.index == 2 && pastList.isEmpty) {
      fetchData(type: 'past');
    }
  }

  Future<void> fetchData({required String type, bool isPagination = false}) async {
    try {
      if (type == 'upcoming') {
        if (isUpcomingLoading.value || (isPagination && !upcomingHasMoreData.value)) return;
        isUpcomingLoading.value = true;

        final response = await _dio.get(upcomingBaseUrl, queryParameters: {
          "limit": 8,
          "page": upcomingCurrentPage.value,
        });

        if (response.statusCode == 200) {
          final mentorshipResponse = MentorshipCardList.fromJson(response.data);
          upcomingLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;

          if (mentorshipResponse.data != null) {
            if (isPagination) {
              upcomingList.addAll(mentorshipResponse.data!);
            } else {
              upcomingList.value = mentorshipResponse.data!;
            }
          }

          upcomingHasMoreData.value = upcomingCurrentPage.value < upcomingLastPage.value;
        }
      } else if (type == 'past') {
        if (isPastLoading.value || (isPagination && !pastHasMoreData.value)) return;
        isPastLoading.value = true;

        final response = await _dio.get(pastBaseUrl, queryParameters: {
          "limit": 8,
          "page": pastCurrentPage.value,
        });

        if (response.statusCode == 200) {
          final mentorshipResponse = MentorshipCardList.fromJson(response.data);
          pastLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;

          if (mentorshipResponse.data != null) {
            if (isPagination) {
              pastList.addAll(mentorshipResponse.data!);
            } else {
              pastList.value = mentorshipResponse.data!;
            }
          }

          pastHasMoreData.value = pastCurrentPage.value < pastLastPage.value;
        }
      } else if (type == 'running') {
        if (isRunningLoading.value || (isPagination && !runningHasMoreData.value)) return;
        isRunningLoading.value = true;

        final response = await _dio.get(runningBaseUrl, queryParameters: {
          "limit": 8,
          "page": runningCurrentPage.value,
        });

        if (response.statusCode == 200) {
          final mentorshipResponse = MentorshipCardList.fromJson(response.data);
          runningLastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;

          if (mentorshipResponse.data != null) {
            if (isPagination) {
              runningList.addAll(mentorshipResponse.data!);
            } else {
              runningList.value = mentorshipResponse.data!;
            }
          }

          runningHasMoreData.value = runningCurrentPage.value < runningLastPage.value;
        }
      }
    } catch (e) {
      // log error if needed
    } finally {
      if (type == 'upcoming') isUpcomingLoading.value = false;
      if (type == 'past') isPastLoading.value = false;
      if (type == 'running') isRunningLoading.value = false;
    }
  }

  void loadMore(String type) {
    if (type == 'upcoming' && upcomingHasMoreData.value && !isUpcomingLoading.value) {
      upcomingCurrentPage.value++;
      fetchData(type: 'upcoming', isPagination: true);
    } else if (type == 'past' && pastHasMoreData.value && !isPastLoading.value) {
      pastCurrentPage.value++;
      fetchData(type: 'past', isPagination: true);
    } else if (type == 'running' && runningHasMoreData.value && !isRunningLoading.value) {
      runningCurrentPage.value++;
      fetchData(type: 'running', isPagination: true);
    }
  }

  Future<void> getMentorshipData() async {
    try {
      isLoading.value = true;
      final response = await _dio.get(apiUrl);
      if (response.statusCode == 200) {
        mentorshipData.value = MentorshipModel.fromJson(response.data);
      }
    } catch (e) {
      // handle
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> getCardDetails({bool isPagination = false}) async {
    if (isListLoading.value || (!hasMoreData.value && isPagination)) return;

    isListLoading.value = true;

    try {
      final response = await _dio.get(baseUrl.value, queryParameters: {
        "limit": 8,
        "page": currentPage.value,
      });

      if (response.statusCode == 200) {
        final mentorshipResponse = MentorshipCardList.fromJson(response.data);
        lastPage.value = mentorshipResponse.pagination?.lastPage ?? 1;

        if (mentorshipResponse.data != null) {
          if (isPagination) {
            mentorshipList.addAll(mentorshipResponse.data!);
          } else {
            mentorshipList.value = mentorshipResponse.data!;
          }
        }

        hasMoreData.value = currentPage.value < lastPage.value;
      }
    } catch (e) {
      // handle
    } finally {
      isListLoading.value = false;
    }
  }

  Future<void> fetchMentorList() async {
    if (isMentorListLoading.value) return;

    isMentorListLoading.value = true;

    try {
      final response = await _dio.get(urlMentor);
      if (response.statusCode == 200) {
        final jsonResponse = response.data;
        final MentorList mentorListData = MentorList.fromJson(jsonResponse);
        mentorList.value = mentorListData.data;
      } else {
        errorMessage.value = "Failed to fetch data. Status code: ${response.statusCode}";
      }
    } catch (e) {
      errorMessage.value = "An error occurred: $e";
    } finally {
      isMentorListLoading.value = false;
    }
  }
}

