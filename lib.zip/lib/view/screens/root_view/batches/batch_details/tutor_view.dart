import 'package:flutter/material.dart';

class TutorView extends StatelessWidget {
  const TutorView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Tutor Tab'),
    );
  }
}
