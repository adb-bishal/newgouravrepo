// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:stockpathshala_beta/model/utils/style_resource.dart';
// import 'package:stockpathshala_beta/view/screens/base_view/base_view_screen.dart';
// import 'package:stockpathshala_beta/view/widgets/button_view/animated_box.dart';
// import '../../../../model/models/common_container_model/common_container_model.dart';
// import '../../../../model/utils/app_constants.dart';
// import '../../../../model/utils/color_resource.dart';
// import '../../../../model/utils/dimensions_resource.dart';
// import '../../../../model/utils/image_resource.dart';
// import '../../../../view_model/controllers/root_view_controller/live_classes_controller/filter_controller/filter_controller.dart';
// import '../../../../view_model/controllers/root_view_controller/past_live_classes_controller/past_live_controller.dart';
// import '../../../../view_model/routes/app_pages.dart';
// import '../../../widgets/circular_indicator/circular_indicator_widget.dart';
// import '../../../widgets/image_provider/image_provider.dart';
// import '../../../widgets/no_data_found/no_data_found.dart';
// import '../../../widgets/search_widget/search_container.dart';
// import '../../../widgets/shimmer_widget/shimmer_widget.dart';
// import '../live_classes_view/filter_view/filter_view.dart';
//
// class PastClassesView extends StatelessWidget {
//   const PastClassesView({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return BaseView(
//       onAppBarTitleBuilder: (context, controller) => const TitleBarCentered(
//         titleText: "Class Recordings",
//       ),
//       onActionBuilder: (context, controller) => [
//         InkWell(
//             onTap: () {
//               buildShowModalBottomSheet(context, Obx(() {
//                 return controller.isClearLoading.value
//                     ? const CircularProgressIndicator()
//                     : LiveFilterScreen(
//                         onClear: (val) {
//                           //controller.listOFSelectedLang.clear();
//                           controller.selectedRating.value = val['rating'];
//                           controller.listOFSelectedDuration.clear();
//                           controller.listOFSelectedCat.clear();
//                           // controller.selectedLevel.value = val['level'];
//                           controller.isClearLoading.value = true;
//                           Future.delayed(Duration.zero, () {
//                             controller.isClearLoading.value = false;
//                           });
//                           controller.selectedSub.value = val['is_free'];
//                           controller.listofSelectedTeacher.value =
//                               val['teacher'];
//                           controller.getLiveData(
//                             pageNo: 1,
//                             categoryId: controller.listOFSelectedCat
//                                 .map((element) => element.id)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             duration: controller.listOFSelectedDuration
//                                 .map((element) => element.optionName)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             teacherId: controller.listofSelectedTeacher
//                                 .map((element) => element.id)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             //langId: controller.listOFSelectedLang.map((element) => element.id).toList().toString().replaceAll("[", "").replaceAll("]", "").removeAllWhitespace,
//                             // rating: controller.selectedRating,
//                             subscriptionLevel: val['is_free'].optionName,
//                           );
//                           Get.back();
//                         },
//                         listOfSelectedTeacher: controller.listofSelectedTeacher,
//                         isHideTeacher: false,
//                         isHideLevel: true,
//                         selectedSubscription: controller.selectedSub.value,
//                         listOFSelectedLevel: const [],
//                         listOFSelectedCat: controller.listOFSelectedCat,
//                         listOFSelectedDuration:
//                             controller.listOFSelectedDuration,
//                         listOFSelectedLang: const [],
//                         listOFSelectedRating: controller.selectedRating,
//                         isPastFilter: true,
//                         onApply: (val) {
//                           // controller.selectedLevel.value = val['level'];
//                           controller.selectedSub.value = val['is_free'];
//                           controller.listofSelectedTeacher.value =
//                               val['teacher'];
//                           controller.selectedRating.value = val['rating'];
//                           controller.listOFSelectedCat.value = val['category'];
//                           //controller.listOFSelectedLang.value = val['language'];
//                           controller.listOFSelectedDuration.value =
//                               val['duration'];
//                           controller.getLiveData(
//                             pageNo: 1,
//                             categoryId: controller.listOFSelectedCat
//                                 .map((element) => element.id)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             teacherId: controller.listofSelectedTeacher
//                                 .map((element) => element.id)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             duration: controller.listOFSelectedDuration
//                                 .map((element) => element.optionName)
//                                 .toList()
//                                 .toString()
//                                 .replaceAll("[", "")
//                                 .replaceAll("]", "")
//                                 .removeAllWhitespace,
//                             subscriptionLevel:
//                                 controller.selectedSub.value.optionName,
//                           );
//                         },
//                       );
//               }), isDark: false, isDismissible: true)
//                   .then((value) {
//                 Get.delete<ClassesFilterController>();
//               });
//             },
//             child: Padding(
//               padding: const EdgeInsets.all(3.0),
//               child: Image.asset(
//                 ImageResource.instance.filterIcon,
//                 height: 18,
//               ),
//             ))
//       ],
//       isBackShow: true,
//       onBackClicked: (context, controller) {
//         Get.back();
//       },
//       viewControl: PastClassesController(),
//       onPageBuilder: (context, controller) =>
//           _mainPageBuilder(context, controller),
//     );
//   }
//
//   Widget _mainPageBuilder(
//       BuildContext context, PastClassesController controller) {
//     return RefreshIndicator(
//       color: ColorResource.primaryColor,
//       onRefresh: controller.onRefresh,
//       child: SingleChildScrollView(
//         controller: controller.dataPagingController.value.scrollController,
//         padding: const EdgeInsets.symmetric(
//             horizontal: DimensionResource.marginSizeDefault),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const SizedBox(
//               height: DimensionResource.marginSizeDefault,
//             ),
//             Obx(() {
//               return SearchWidget(
//                 enableMargin: false,
//                 textEditingController: controller.searchController.value,
//                 onChange: controller.onClassSearch,
//                 onClear: () {
//                   controller.onClassSearch("");
//                 },
//               );
//             }),
//             const SizedBox(
//               height: DimensionResource.marginSizeSmall,
//             ),
//             Text(
//               "View class recordings",
//               style: StyleResource.instance.styleSemiBold(),
//             ),
//             const SizedBox(
//               height: DimensionResource.marginSizeSmall,
//             ),
//             videoCourseWrapList(
//                 pastClassesController: controller, context: context),
//             const SizedBox(
//               height: DimensionResource.marginSizeSmall,
//             ),
//             Visibility(
//                 visible:
//                     controller.dataPagingController.value.isDataLoading.value,
//                 child: const Padding(
//                   padding: EdgeInsets.only(bottom: 15.0),
//                   child: CommonCircularIndicator(),
//                 )),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget videoCourseWrapList(
//       {required PastClassesController pastClassesController,
//       required BuildContext context}) {
//     return Obx(() => pastClassesController.isDataLoading.value
//         ? ShimmerEffect.instance.liveClassLoader()
//         : pastClassesController.dataPagingController.value.list.isEmpty
//             ? const SizedBox(
//                 height: 500,
//                 child: NoDataFound(
//                   showText: true,
//                   text: "Be a Pro to Watch Class Recordings",
//                 ))
//             : Wrap(
//                 spacing: DimensionResource.marginSizeSmall,
//                 runSpacing: DimensionResource.marginSizeExtraSmall,
//                 children: List.generate(
//                     pastClassesController
//                         .dataPagingController.value.list.length, (index) {
//                   CommonDatum data = CommonDatum.fromJson(pastClassesController
//                       .dataPagingController.value.list
//                       .elementAt(index)
//                       .toJson());
//                   return Padding(
//                     padding: EdgeInsets.only(
//                         bottom: pastClassesController.dataPagingController.value
//                                         .list.length -
//                                     1 ==
//                                 index
//                             ? DimensionResource.marginSizeDefault
//                             : 0),
//                     child: _pastLiveClassesView(index,
//                         height: 120,
//                         fontSize: DimensionResource.marginSizeSmall + 3,
//                         data: data,
//                         isPast: true,
//                         pastClassesController: pastClassesController,
//                         onItemTap: (data) {},
//                         size: MediaQuery.of(context).size),
//                   );
//                 }),
//               ));
//   }
// }
//
// Widget _pastLiveClassesView(int index,
//     {double height = 120,
//     double fontSize = DimensionResource.fontSizeExtraSmall - 2,
//     bool isPast = false,
//     Function(CommonDatum data)? onItemTap,
//     required CommonDatum data,
//     required PastClassesController pastClassesController,
//     required Size size}) {
//   return GestureDetector(
//     onTap: () {
//       AppConstants.instance.liveId.value = (data.id.toString());
//       Get.toNamed(Routes.liveClassDetail(id: data.id.toString()),
//           arguments: [isPast, data.id.toString()]);
//       if (onItemTap != null) {
//         onItemTap(data);
//       }
//     },
//     child: Container(
//       height: height,
//       margin: const EdgeInsets.only(bottom: 10),
//       decoration: BoxDecoration(
//           color: ColorResource.white,
//           shape: BoxShape.rectangle,
//           border: Border.all(color: ColorResource.black),
//           borderRadius: BorderRadius.circular(
//               DimensionResource.appDefaultContainerRadius)),
//       child: Row(
//         children: [
//           ClipRRect(
//             borderRadius: const BorderRadius.horizontal(
//               left:
//                   Radius.circular(DimensionResource.appDefaultContainerRadius),
//             ),
//             child: SizedBox(
//               height: height,
//               width: 100,
//               child: cachedNetworkImage(
//                 data.preview ?? data.image ?? "",
//                 fit: BoxFit.cover,
//               ),
//             ),
//           ),
//           Expanded(
//             child: Container(
//               height: height,
//               decoration: const BoxDecoration(
//                   color: ColorResource.white,
//                   borderRadius: BorderRadius.horizontal(
//                       right: Radius.circular(
//                           DimensionResource.appDefaultContainerRadius))),
//               padding: const EdgeInsets.all(
//                   DimensionResource.marginSizeExtraSmall + 2),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(5),
//                         color: ColorResource.lightYellowColor),
//                     padding:
//                         const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
//                     child: Text(
//                       data.category?.title ?? '',
//                       style: StyleResource.instance.styleMedium(fontSize: 8),
//                     ),
//                   ),
//                   const SizedBox(
//                     height: DimensionResource.marginSizeExtraSmall,
//                   ),
//                   Text(
//                     "Streamed on ${AppConstants.formatDate(data.startTime)}",
//                     style: StyleResource.instance.styleMedium(
//                         fontSize: DimensionResource.fontSizeExtraSmall - 2,
//                         color: ColorResource.greenDarkColor),
//                     overflow: TextOverflow.ellipsis,
//                     maxLines: 2,
//                   ),
//                   const SizedBox(
//                     height: DimensionResource.marginSizeExtraSmall - 2,
//                   ),
//                   SizedBox(
//                     height: 60,
//                     child: Text(
//                       data.title ?? '',
//                       style: StyleResource.instance.styleMedium(
//                           fontSize: fontSize, color: ColorResource.black),
//                       overflow: TextOverflow.ellipsis,
//                       maxLines: 3,
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 5,
//                   ),
//                 ],
//               ),
//             ),
//           )
//         ],
//       ),
//     ),
//   );
// }
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:stockpathshala_beta/model/utils/style_resource.dart';
import 'package:stockpathshala_beta/view/screens/base_view/base_view_screen.dart';
import 'package:stockpathshala_beta/view/widgets/button_view/animated_box.dart';

import '../../../../model/models/common_container_model/common_container_model.dart';
import '../../../../model/utils/app_constants.dart';
import '../../../../model/utils/color_resource.dart';
import '../../../../model/utils/dimensions_resource.dart';
import '../../../../model/utils/image_resource.dart';

import '../../../../view_model/controllers/root_view_controller/live_classes_controller/filter_controller/filter_controller.dart';
import '../../../../view_model/controllers/root_view_controller/past_live_classes_controller/past_live_controller.dart';

import '../../../../view_model/routes/app_pages.dart';

import '../../../widgets/circular_indicator/circular_indicator_widget.dart';
import '../../../widgets/image_provider/image_provider.dart';
import '../../../widgets/no_data_found/no_data_found.dart';
import '../../../widgets/search_widget/search_container.dart';
import '../../../widgets/shimmer_widget/shimmer_widget.dart';

import '../live_classes_view/filter_view/filter_view.dart';

// class PastClassesView extends StatelessWidget {
//   const PastClassesView({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return BaseView<PastClassesController>(
//       onAppBarTitleBuilder: (context, controller) => const TitleBarCentered(
//         titleText: "Class Recordings",
//       ),
//       onActionBuilder: (context, controller) => [
//         InkWell(
//           onTap: () {
//             buildShowModalBottomSheet(
//               context,
//               Obx(() {
//                 if (controller.isClearLoading.value) {
//                   return const Center(child: CircularProgressIndicator());
//                 }
//                 return LiveFilterScreen(
//                   onClear: (val) {
//                     controller.selectedRating.value = val['rating'];
//                     controller.listOFSelectedDuration.clear();
//                     controller.listOFSelectedCat.clear();
//                    // controller.listOFSelectedDays.clear();
//                     controller.isClearLoading.value = true;
//                     Future.delayed(Duration.zero, () {
//                       controller.isClearLoading.value = false;
//                     });
//                     controller.selectedSub.value = val['is_free'];
//                     controller.listofSelectedTeacher.value = val['teacher'];
//                     controller.listSelectedDate.clear();
//
//                     controller.getLiveData(
//                       pageNo: 1,
//
//                       categoryId: controller.listOFSelectedCat
//                           .map((e) => e.id)
//                           .join(","),
//                       endDate: controller.listSelectedDate.isNotEmpty
//                           ? DateTime.tryParse(controller.listSelectedDate.first.id ?? '')
//                           : null,
//                       duration: controller.listOFSelectedDuration
//                           .map((e) => e.optionName)
//                           .join(","),
//                       teacherId: controller.listofSelectedTeacher
//                           .map((e) => e.id)
//                           .join(","),
//                       subscriptionLevel: val['is_free'].optionName,
//                     );
//                     Get.back();
//                   },
//                   listOfSelectedTeacher: controller.listofSelectedTeacher,
//                   isHideTeacher: false,
//                   isHideLevel: true,
//                   selectedSubscription: controller.selectedSub.value,
//                   listOFSelectedLevel: const [],
//                   listOFSelectedCat: controller.listOFSelectedCat,
//                   listOFSelectedDuration: controller.listOFSelectedDuration,
//                   listOFSelectedLang: const [],
//                   listOFSelectedRating: controller.selectedRating,
//                   isPastFilter: true,
//                   onApply: (val) {
//                     controller.selectedSub.value = val['is_free'];
//                     controller.listofSelectedTeacher.value = val['teacher'];
//                     controller.selectedRating.value = val['rating'];
//                     controller.listOFSelectedCat.value = val['category'];
//                    // controller.listOFSelectedDays.value =val["end_datetime"];
//                     controller.listOFSelectedDuration.value = val['duration'];
//                     controller.listSelectedDate.value = val['days'];
//
//                     controller.getLiveData(
//                       pageNo: 1,
//                       endDate: controller.listSelectedDate.isNotEmpty
//                           ? DateTime.tryParse(controller.listSelectedDate.first.optionName ?? '')
//                           : null,
//                       categoryId: controller.listOFSelectedCat
//                           .map((e) => e.id)
//                           .join(","),
//                       teacherId: controller.listofSelectedTeacher
//                           .map((e) => e.id)
//                           .join(","),
//                       duration:
//                       controller.listOFSelectedDuration.map((e) => e.optionName).join(","),
//                       subscriptionLevel: controller.selectedSub.value.optionName,
//                     );
//                     Get.back();
//                   }, listSelectedDate: controller.listSelectedDate,
//                 );
//               }),
//               isDark: false,
//               isDismissible: true,
//             ).then((value) {
//               Get.delete<ClassesFilterController>();
//             });
//           },
//           child: Padding(
//             padding: const EdgeInsets.all(3.0),
//             child: Image.asset(
//               ImageResource.instance.filterIcon,
//               height: 18,
//             ),
//           ),
//         )
//       ],
//       isBackShow: true,
//       onBackClicked: (context, controller) {
//         Get.back();
//       },
//       viewControl: PastClassesController(),
//       onPageBuilder: (context, controller) => _mainPageBuilder(context, controller),
//     );
//   }
//
//   Widget _mainPageBuilder(BuildContext context, PastClassesController controller) {
//     return RefreshIndicator(
//       color: ColorResource.primaryColor,
//       onRefresh: controller.onRefresh,
//       child: SingleChildScrollView(
//         controller: controller.dataPagingController.value.scrollController,
//         padding: const EdgeInsets.symmetric(horizontal: DimensionResource.marginSizeDefault),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const SizedBox(height: DimensionResource.marginSizeDefault),
//             Obx(() {
//               return SearchWidget(
//                 enableMargin: false,
//                 textEditingController: controller.searchController.value,
//                 onChange: controller.onClassSearch,
//                 onClear: () {
//                   controller.onClassSearch("");
//                 },
//               );
//             }),
//             const SizedBox(height: DimensionResource.marginSizeSmall),
//             Text(
//               "View class recordings",
//               style: StyleResource.instance.styleSemiBold(),
//             ),
//             const SizedBox(height: DimensionResource.marginSizeSmall),
//             videoCourseWrapList(
//               pastClassesController: controller,
//               context: context,
//             ),
//             const SizedBox(height: DimensionResource.marginSizeSmall),
//             Obx(() {
//               return Visibility(
//                 visible: controller.dataPagingController.value.isDataLoading.value,
//                 child: const Padding(
//                   padding: EdgeInsets.only(bottom: 15.0),
//                   child: CommonCircularIndicator(),
//                 ),
//               );
//             }),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget videoCourseWrapList({
//     required PastClassesController pastClassesController,
//     required BuildContext context,
//   }) {
//     return Obx(() {
//       if (pastClassesController.isDataLoading.value) {
//         return ShimmerEffect.instance.liveClassLoader();
//       } else if (pastClassesController.dataPagingController.value.list.isEmpty) {
//         return const SizedBox(
//           height: 500,
//           child: NoDataFound(
//             showText: true,
//             text: "Be a Pro to Watch Class Recordings",
//           ),
//         );
//       } else {
//         return Wrap(
//           spacing: DimensionResource.marginSizeSmall,
//           runSpacing: DimensionResource.marginSizeExtraSmall,
//           children: List.generate(
//             pastClassesController.dataPagingController.value.list.length,
//                 (index) {
//               final data = CommonDatum.fromJson(
//                 pastClassesController.dataPagingController.value.list[index].toJson(),
//               );
//               return Padding(
//                 padding: EdgeInsets.only(
//                   bottom: index == pastClassesController.dataPagingController.value.list.length - 1
//                       ? DimensionResource.marginSizeDefault
//                       : 0,
//                 ),
//                 child: _pastLiveClassesView(
//                   index,
//                   height: 120,
//                   fontSize: DimensionResource.marginSizeSmall + 3,
//                   data: data,
//                   isPast: true,
//                   pastClassesController: pastClassesController,
//                   onItemTap: (data) {},
//                   size: MediaQuery.of(context).size,
//                 ),
//               );
//             },
//           ),
//         );
//       }
//     });
//   }
// }
//
// Widget _pastLiveClassesView(
//     int index, {
//       double height = 120,
//       double fontSize = DimensionResource.fontSizeExtraSmall - 2,
//       bool isPast = false,
//       Function(CommonDatum data)? onItemTap,
//       required CommonDatum data,
//       required PastClassesController pastClassesController,
//       required Size size,
//     }) {
//   return GestureDetector(
//     onTap: () {
//       AppConstants.instance.liveId.value = data.id.toString();
//       Get.toNamed(
//         Routes.liveClassDetail(id: data.id.toString()),
//         arguments: [isPast, data.id.toString()],
//       );
//       if (onItemTap != null) {
//         onItemTap(data);
//       }
//     },
//     child: Container(
//       height: height,
//       margin: const EdgeInsets.only(bottom: 10),
//       decoration: BoxDecoration(
//         color: ColorResource.white,
//         shape: BoxShape.rectangle,
//         border: Border.all(color: ColorResource.black),
//         borderRadius: BorderRadius.circular(DimensionResource.appDefaultContainerRadius),
//       ),
//       child: Row(
//         children: [
//           ClipRRect(
//             borderRadius: const BorderRadius.horizontal(
//               left: Radius.circular(DimensionResource.appDefaultContainerRadius),
//             ),
//             child: SizedBox(
//               height: height,
//               width: 100,
//               child: cachedNetworkImage(
//                 data.preview ?? data.image ?? "",
//                 fit: BoxFit.cover,
//               ),
//             ),
//           ),
//           Expanded(
//             child: Container(
//               height: height,
//               decoration: const BoxDecoration(
//                 color: ColorResource.white,
//                 borderRadius: BorderRadius.horizontal(
//                   right: Radius.circular(DimensionResource.appDefaultContainerRadius),
//                 ),
//               ),
//               padding: const EdgeInsets.all(DimensionResource.marginSizeExtraSmall + 2),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(5),
//                       color: ColorResource.lightYellowColor,
//                     ),
//                     padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
//                     child: Text(
//                       data.category?.title ?? '',
//                       style: StyleResource.instance.styleMedium(fontSize: 8),
//                     ),
//                   ),
//                   const SizedBox(height: DimensionResource.marginSizeExtraSmall),
//                   Text(
//                     "Streamed on ${AppConstants.formatDate(data.startTime)}",
//                     style: StyleResource.instance.styleMedium(
//                       fontSize: DimensionResource.fontSizeExtraSmall - 2,
//                       color: ColorResource.greenDarkColor,
//                     ),
//                     overflow: TextOverflow.ellipsis,
//                     maxLines: 2,
//                   ),
//                   const SizedBox(height: DimensionResource.marginSizeExtraSmall - 2),
//                   SizedBox(
//                     height: 60,
//                     child: Text(
//                       data.title ?? '',
//                       style: StyleResource.instance.styleMedium(
//                         fontSize: fontSize,
//                         color: ColorResource.black,
//                       ),
//                       overflow: TextOverflow.ellipsis,
//                       maxLines: 3,
//                     ),
//                   ),
//                   const SizedBox(height: 5),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     ),
//   );
// }

import 'package:stockpathshala_beta/service/utils/Session.dart';

class PastClassesView extends StatelessWidget {
  const PastClassesView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseView(
      onAppBarTitleBuilder: (context, controller) => const TitleBarCentered(
        titleText: "Class Recordings",
      ),
      onActionBuilder: (context, controller) => [
        InkWell(
            onTap: () {
              buildShowModalBottomSheet(context, Obx(() {
                return controller.isClearLoading.value
                    ? const CircularProgressIndicator()
                    : LiveFilterScreen(
                  onClear: (val) {
                    //controller.listOFSelectedLang.clear();
                    controller.selectedRating.value = val['rating'];
                    controller.listOFSelectedDuration.clear();
                    controller.listOFSelectedCat.clear();
                    controller.listOFSelectedDays.clear();
                    // controller.selectedLevel.value = val['level'];
                    controller.isClearLoading.value = true;
                    Future.delayed(Duration.zero, () {
                      controller.isClearLoading.value = false;
                    });
                    controller.selectedSub.value = val['is_free'];
                    controller.listofSelectedTeacher.value =
                    val['teacher'];
                    controller.getLiveData(
                      pageNo: 1,
                      categoryId: controller.listOFSelectedCat
                          .map((element) => element.id)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                      duration: controller.listOFSelectedDuration
                          .map((element) => element.optionName)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                    dateFilter: Session.getSelectedDateFilter().toString(),
                      teacherId: controller.listofSelectedTeacher
                          .map((element) => element.id)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                      //langId: controller.listOFSelectedLang.map((element) => element.id).toList().toString().replaceAll("[", "").replaceAll("]", "").removeAllWhitespace,
                      // rating: controller.selectedRating,
                      subscriptionLevel: val['is_free'].optionName,
                    );
                    Get.back();
                  },
                  listOfSelectedTeacher: controller.listofSelectedTeacher,
                  isHideTeacher: false,
                  isHideLevel: true,
                  selectedSubscription: controller.selectedSub.value,
                  listOFSelectedLevel: const [],
                  listOFSelectedCat: controller.listOFSelectedCat,
                  listOFSelectedDays:controller.listOFSelectedDays,
                  listOFSelectedDuration:
                  controller.listOFSelectedDuration,
                  listOFSelectedLang: const [],
                  listOFSelectedRating: controller.selectedRating,
                  isPastFilter: true,
                  onApply: (val) {
                    // controller.selectedLevel.value = val['level'];
                    controller.selectedSub.value = val['is_free'];
                    controller.listofSelectedTeacher.value =
                    val['teacher'];
                    controller.selectedRating.value = val['rating'];
                    controller.listOFSelectedCat.value = val['category'];
                   controller.listOFSelectedDays=val['dateFilter'];
                    //controller.listOFSelectedLang.value = val['language'];
                    controller.listOFSelectedDuration.value =
                    val['duration'];
                    controller.getLiveData(
                      pageNo: 1,
                      categoryId: controller.listOFSelectedCat
                          .map((element) => element.id)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                     dateFilter: Session.getSelectedDateFilter()?.value,
                      teacherId: controller.listofSelectedTeacher
                          .map((element) => element.id)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                      duration: controller.listOFSelectedDuration
                          .map((element) => element.optionName)
                          .toList()
                          .toString()
                          .replaceAll("[", "")
                          .replaceAll("]", "")
                          .removeAllWhitespace,
                      subscriptionLevel:
                      controller.selectedSub.value.optionName,
                    );
                  },
                );
              }), isDark: false, isDismissible: true)
                  .then((value) {
                Get.delete<ClassesFilterController>();
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(3.0),
              child: Image.asset(
                ImageResource.instance.filterIcon,
                height: 18,
              ),
            ))
      ],
      isBackShow: true,
      onBackClicked: (context, controller) {
        Get.back();
      },
      viewControl: PastClassesController(),
      onPageBuilder: (context, controller) =>
          _mainPageBuilder(context, controller),
    );
  }

  Widget _mainPageBuilder(
      BuildContext context, PastClassesController controller) {
    return RefreshIndicator(
      color: ColorResource.primaryColor,
      onRefresh: controller.onRefresh,
      child: SingleChildScrollView(
        controller: controller.dataPagingController.value.scrollController,
        padding: const EdgeInsets.symmetric(
            horizontal: DimensionResource.marginSizeDefault),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: DimensionResource.marginSizeDefault,
            ),
            Obx(() {
              return SearchWidget(
                enableMargin: false,
                textEditingController: controller.searchController.value,
                onChange: controller.onClassSearch,
                onClear: () {
                  controller.onClassSearch("");
                },
              );
            }),
            const SizedBox(
              height: DimensionResource.marginSizeSmall,
            ),
            Text(
              "View class recordings",
              style: StyleResource.instance.styleSemiBold(),
            ),
            const SizedBox(
              height: DimensionResource.marginSizeSmall,
            ),
            videoCourseWrapList(
                pastClassesController: controller, context: context),
            const SizedBox(
              height: DimensionResource.marginSizeSmall,
            ),
            Visibility(
                visible:
                controller.dataPagingController.value.isDataLoading.value,
                child: const Padding(
                  padding: EdgeInsets.only(bottom: 15.0),
                  child: CommonCircularIndicator(),
                )),
          ],
        ),
      ),
    );
  }

  Widget videoCourseWrapList(
      {required PastClassesController pastClassesController,
        required BuildContext context}) {
    return Obx(() => pastClassesController.isDataLoading.value
        ? ShimmerEffect.instance.liveClassLoader()
        : pastClassesController.dataPagingController.value.list.isEmpty
        ? const SizedBox(
        height: 500,
        child: NoDataFound(
          showText: true,
          text: "Be a Pro to Watch Class Recordings",
        ))
        : Wrap(
      spacing: DimensionResource.marginSizeSmall,
      runSpacing: DimensionResource.marginSizeExtraSmall,
      children: List.generate(
          pastClassesController
              .dataPagingController.value.list.length, (index) {
        CommonDatum data = CommonDatum.fromJson(pastClassesController
            .dataPagingController.value.list
            .elementAt(index)
            .toJson());
        return Padding(
          padding: EdgeInsets.only(
              bottom: pastClassesController.dataPagingController.value
                  .list.length -
                  1 ==
                  index
                  ? DimensionResource.marginSizeDefault
                  : 0),
          child: _pastLiveClassesView(index,
              height: 120,
              fontSize: DimensionResource.marginSizeSmall + 3,
              data: data,
              isPast: true,
              pastClassesController: pastClassesController,
              onItemTap: (data) {},
              size: MediaQuery.of(context).size),
        );
      }),
    ));
  }
}

Widget _pastLiveClassesView(int index,
    {double height = 120,
      double fontSize = DimensionResource.fontSizeExtraSmall - 2,
      bool isPast = false,
      Function(CommonDatum data)? onItemTap,
      required CommonDatum data,
      required PastClassesController pastClassesController,
      required Size size}) {
  return GestureDetector(
    onTap: () {
      AppConstants.instance.liveId.value = (data.id.toString());
      Get.toNamed(Routes.liveClassDetail(id: data.id.toString()),
          arguments: [isPast, data.id.toString()]);
      if (onItemTap != null) {
        onItemTap(data);
      }
    },
    child: Container(
      height: height,
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          color: ColorResource.white,
          shape: BoxShape.rectangle,
          border: Border.all(color: ColorResource.black),
          borderRadius: BorderRadius.circular(
              DimensionResource.appDefaultContainerRadius)),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.horizontal(
              left:
              Radius.circular(DimensionResource.appDefaultContainerRadius),
            ),
            child: SizedBox(
              height: height,
              width: 100,
              child: cachedNetworkImage(
                data.preview ?? data.image ?? "",
                fit: BoxFit.cover,
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: height,
              decoration: const BoxDecoration(
                  color: ColorResource.white,
                  borderRadius: BorderRadius.horizontal(
                      right: Radius.circular(
                          DimensionResource.appDefaultContainerRadius))),
              padding: const EdgeInsets.all(
                  DimensionResource.marginSizeExtraSmall + 2),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: ColorResource.lightYellowColor),
                    padding:
                    const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
                    child: Text(
                      data.category?.title ?? '',
                      style: StyleResource.instance.styleMedium(fontSize: 8),
                    ),
                  ),
                  const SizedBox(
                    height: DimensionResource.marginSizeExtraSmall,
                  ),
                  Text(
                    "Streamed on ${AppConstants.formatDate(data.startTime)}",
                    style: StyleResource.instance.styleMedium(
                        fontSize: DimensionResource.fontSizeExtraSmall - 2,
                        color: ColorResource.greenDarkColor),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                  ),
                  const SizedBox(
                    height: DimensionResource.marginSizeExtraSmall - 2,
                  ),
                  SizedBox(
                    height: 60,
                    child: Text(
                      data.title ?? '',
                      style: StyleResource.instance.styleMedium(
                          fontSize: fontSize, color: ColorResource.black),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 3,
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    ),
  );
}
