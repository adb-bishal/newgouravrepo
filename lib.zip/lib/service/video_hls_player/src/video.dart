import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:stockpathshala_beta/model/utils/color_resource.dart';
import 'package:stockpathshala_beta/model/utils/style_resource.dart';
import 'package:stockpathshala_beta/service/video_hls_player/lecle_yoyo_player.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/model/models.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/utils/utils.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/widgets/video_loading.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/widgets/video_quality_picker.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/widgets/video_quality_widget.dart';
import 'package:stockpathshala_beta/service/video_hls_player/src/widgets/widget_bottombar.dart';
import 'package:stockpathshala_beta/view/widgets/log_print/log_print_condition.dart';
import 'package:stockpathshala_beta/view_model/controllers/root_view_controller/video_course_detail_controller/video_course_detail_controller.dart';
import 'package:video_player/video_player.dart';

import 'responses/regex_response.dart';

class YoYoPlayer extends StatefulWidget {
  /// **Video source**
  /// ```dart
  /// url:"https://example.com/index.m3u8";
  /// ```
  final String url;
  final bool? hideControls;


  /// Custom style for the video player
  ///```dart
  ///videoStyle : VideoStyle(
  ///     playIcon =  Icon(Icons.play_arrow),
  ///     pauseIcon = Icon(Icons.pause),
  ///     fullscreenIcon =  Icon(Icons.fullScreen),
  ///     forwardIcon =  Icon(Icons.skip_next),
  ///     backwardIcon =  Icon(Icons.skip_previous),
  ///     progressIndicatorColors = VideoProgressColors(
  ///       playedColor: Colors.green,
  ///     ),
  ///     qualityStyle = const TextStyle(
  ///       color: Colors.white,
  ///     ),
  ///      qaShowStyle = const TextStyle(
  ///       color: Colors.white,
  ///     ),
  ///   );
  ///```
  final VideoStyle videoStyle;

  /// The style for the loading widget which use while waiting for the video to load.
  /// ```dart
  /// VideoLoadingStyle(
  ///   loading: Center(
  ///      child: Column(
  ///      mainAxisAlignment: MainAxisAlignment.center,
  ///      crossAxisAlignment: CrossAxisAlignment.center,
  ///      children: const [
  ///         Image(
  ///           image: AssetImage('image/yoyo_logo.png'),
  ///           fit: BoxFit.fitHeight,
  ///           height: 50,
  ///         ),
  ///         SizedBox(height: 16.0),
  ///         Text("Loading video..."),
  ///       ],
  ///     ),
  ///   ),
  //  ),
  /// ```
  final VideoLoadingStyle videoLoadingStyle;

  /// Video aspect ratio. Ex: [aspectRatio: 16 / 9 ]
  final double aspectRatio;

  /// Callback function for on fullscreen event.
  final void Function(bool fullScreenTurnedOn)? onFullScreen;

  /// Callback function for start playing a video event. The function will return the type of the playing video.
  final void Function(String videoType)? onPlayingVideo;

  /// Callback function for tapping play video button event.
  final void Function(bool isPlaying)? onPlayButtonTap;

  /// Callback function for fast forward button tap event.
  final ValueChanged<VideoPlayerValue>? onFastForward;

  /// Callback function for rewind button tap event.
  final ValueChanged<VideoPlayerValue>? onRewind;

  /// Callback function for live direct button tap event.
  final ValueChanged<VideoPlayerValue>? onLiveDirectTap;

  /// Callback function for showing menu event.
  final void Function(bool showMenu, bool m3u8Show)? onShowMenu;

  /// Callback function for video init completed event.
  /// This function will expose the video controller and you can use it to track the video progress.
  final void Function(VideoPlayerController controller)? onVideoInitCompleted;
  final void Function(int controller, int duration)? onVideoPosition;

  /// The headers for the video url request.
  final Map<String, String>? headers;

  /// If set to [true] the video will be played after the video initialize steps are completed and vice versa.
  /// Default value is [true].
  final bool autoPlayVideoAfterInit;

  /// If set to [true] the video will be played in full screen mode after the video initialize steps is completed and vice versa.
  /// Default value is [false].
  final bool displayFullScreenAfterInit;

  /// Callback function execute when the file cached to the device local storage and it will return a list of
  /// paths of the cached files.
  ///
  /// ***This function will be called only when the [allowCacheFile] property is set to true.***
  final void Function(List<File>? files)? onCacheFileCompleted;

  /// Callback function execute when there is an error occurs while caching the file.
  /// The error will be return within the function.
  final void Function(dynamic error)? onCacheFileFailed;

  /// If set to [true] the video will be cached into the device local storage and the [onCacheFileCompleted]
  /// method will be executed after the file is cached.
  final bool allowCacheFile;

  /// Callback method for closed caption file event.
  /// You have to return a [ClosedCaptionFile] object for this method.
  final Future<ClosedCaptionFile>? closedCaptionFile;

  /// Provide additional configuration options (optional).
  /// Like setting the audio mode to mix.
  final VideoPlayerOptions? videoPlayerOptions;

  ///
  /// ```dart
  /// YoYoPlayer(
  /// // url types = (m3u8[hls],.mp4,.mkv)
  ///   url : "video_url",
  /// // Video's style
  ///   videoStyle : VideoStyle(),
  /// // Video's loading style
  ///   videoLoadingStyle : VideoLoadingStyle(),
  /// // Video's aspect ratio
  ///   aspectRatio : 16/9,
  /// )
  /// ```
  const YoYoPlayer({
    Key? key,
    required this.url,
    this.aspectRatio = 16 / 9,
    this.videoStyle = const VideoStyle(),
    this.videoLoadingStyle = const VideoLoadingStyle(),
    this.onFullScreen,
    this.onPlayingVideo,
    this.onPlayButtonTap,
    this.onShowMenu,
    this.onFastForward,
    this.onRewind,
    this.headers,
    this.autoPlayVideoAfterInit = true,
    this.displayFullScreenAfterInit = false,
    this.allowCacheFile = false,
    this.onCacheFileCompleted,
    this.onCacheFileFailed,
    this.onVideoInitCompleted,
    this.onVideoPosition,
    this.closedCaptionFile,
    this.videoPlayerOptions,
    this.onLiveDirectTap,
    this.hideControls,
  }) : super(key: key);

  @override
  State<YoYoPlayer> createState() => _YoYoPlayerState();
}

class _YoYoPlayerState extends State<YoYoPlayer>
    with SingleTickerProviderStateMixin {
  /// Video play type (hls,mp4,mkv,offline)
  String? playType;

  /// Animation Controller
  late AnimationController controlBarAnimationController;

  /// Video Top Bar Animation
  Animation<double>? controlTopBarAnimation;

  /// Video Bottom Bar Animation
  Animation<double>? controlBottomBarAnimation;

  /// Video Player Controller
  late VideoPlayerController controller;

  /// Video init error default :false
  bool hasInitError = false;

  /// Video Total Time duration
  String? videoDuration;

  /// Video Seed to
  String? videoSeek;

  /// Video duration 1
  Duration? duration;

  /// Video seek second by user
  double? videoSeekSecond;

  /// Video duration second
  double? videoDurationSecond;

  /// m3u8 data video list for user choice
  List<M3U8Data> yoyo = [];

  /// m3u8 audio list
  List<AudioModel> audioList = [];

  /// m3u8 temp data
  String? m3u8Content;

  /// Subtitle temp data
  String? subtitleContent;

  /// Menu show m3u8 list
  bool m3u8Show = false;

  /// Video full screen
  bool fullScreen = false;

  /// Menu show
  bool showMenu = false;

  /// Auto show subtitle
  bool showSubtitles = false;

  /// Video status
  bool? isOffline;

  /// Video auto quality
  String m3u8Quality = "Auto";

  /// Time for duration
  Timer? showTime;

  /// Video quality overlay
  OverlayEntry? overlayEntry;

  /// Global key to calculate quality options
  GlobalKey videoQualityKey = GlobalKey();

  /// Last playing position of the current video before changing the quality
  Duration? lastPlayedPos;

  double _playbackSpeed = 1.0 ;//Default playback speed

  /// If set to true the live direct button will display with the live color
  /// and if not it will display with the disable color.
  bool isAtLivePosition = true;
  late VideoCourseDetailController controller2;
  @override
  void initState() {
    super.initState();
    logPrint("i am in YoYoPlayer");
    controller2 = Get.put(VideoCourseDetailController());
    urlCheck(widget.url);

    /// Control bar animation
    controlBarAnimationController = AnimationController(
        duration: const Duration(milliseconds: 300), vsync: this);
    controlTopBarAnimation = Tween(begin: -(36.0 + 0.0 * 2), end: 0.0)
        .animate(controlBarAnimationController);
    controlBottomBarAnimation = Tween(begin: -(36.0 + 0.0 * 2), end: 0.0)
        .animate(controlBarAnimationController);

    WidgetsBinding.instance.addPostFrameCallback((callback) {
      WidgetsBinding.instance.addPersistentFrameCallback((callback) {
        if (!mounted) return;
        var orientation = MediaQuery.of(context).orientation;
        bool? fullScr;

        if (orientation == Orientation.landscape) {
          // Horizontal screen
          fullScr = true;
          SystemChrome.setEnabledSystemUIMode(
            SystemUiMode.manual,
            overlays: [SystemUiOverlay.bottom],
          );
        } else if (orientation == Orientation.portrait) {
          // Portrait screen
          fullScr = false;
          SystemChrome.setEnabledSystemUIMode(
            SystemUiMode.manual,
            overlays: SystemUiOverlay.values,
          );
        }

        if (fullScr != fullScreen) {
          setState(() {
            fullScreen = !fullScreen;
            _navigateLocally(context);
            widget.onFullScreen?.call(fullScreen);
          });
        }

        WidgetsBinding.instance.scheduleFrame();
      });
    });

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      //DeviceOrientation.landscapeLeft,
      // DeviceOrientation.landscapeRight,
    ]);

    // if (widget.videoStyle.enableSystemOrientationsOverride) {
    //   SystemChrome.setPreferredOrientations(
    //     widget.videoStyle.orientation ?? DeviceOrientation.values,
    //   );
    // }

    if (widget.displayFullScreenAfterInit) {
      // toggleFullScreen();
      ScreenUtils.toggleFullScreen(fullScreen);
    }

    // FlutterScreenWake.keepOn(true);
  }

  @override
  void dispose() {
    m3u8Clean();
    controller.dispose();
    controlBarAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: fullScreen
          ? MediaQuery.of(context).size.calculateAspectRatio()
          : widget.aspectRatio,
      child: controller.value.isInitialized
          ? Stack(
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    if ((widget.hideControls ?? false)) {
                      togglePlay();
                    } else {
                      toggleControls();
                    }
                    removeOverlay();
                  },
                  onDoubleTap: () {
                    togglePlay();
                    removeOverlay();
                  },
                  child: Center(
                    child: AspectRatio(
                      aspectRatio: controller.value.aspectRatio,
                      child: VideoPlayer(controller),
                    ),
                  ),
                ),
                if (widget.hideControls == false || widget.hideControls == null)
                  ...videoBuiltInChildren(),
              ],
            )
          : VideoLoading(loadingStyle: widget.videoLoadingStyle),
    );
  }

  List<Widget> videoBuiltInChildren() {
    return [
      actionBar(),
      liveDirectButton(),
      bottomBar(),
      // m3u8List(),

    ];
  }

  /// Video player ActionBar
  Widget actionBar() {
    return Visibility(
      visible: showMenu,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        child: Align(
          alignment: Alignment.topRight,
          child: VideoQualityWidget(
            key: videoQualityKey,
            videoStyle: widget.videoStyle,
            onTap: () {
              // Quality function
              setState(() {
                m3u8Show = !m3u8Show;
                if (m3u8Show) {
                  showOverlay();
                } else {
                  removeOverlay();
                }
              });
            },
            child: Text(
                (m3u8Quality.split("x").toList().length < 2)
                    ? m3u8Quality
                    : "${m3u8Quality.split("x")[1]}p",
                style: StyleResource.instance
                    .styleRegular(fontSize: 10, color: ColorResource.white)),
          ),
        ),
      ),
    );
  }




  /// Video player BottomBar
  Widget bottomBar() {
    return Visibility(
      visible: showMenu,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              InkWell(
                onTap: () {
                  controller.rewind().then((value) {
                    widget.onRewind?.call(controller.value);
                  });
                },
                child: const SizedBox(
                  height: 50,
                  width: 50,
                  child: Icon(
                    Icons.fast_rewind_rounded,
                    color: ColorResource.primaryColor,
                    size: 25,
                  ),
                ),
              ),
              Transform.translate(
                offset: const Offset(0.0, -4.0),
                child: InkWell(
                  onTap: () => togglePlay(),
                  child: () {
                    var defaultIcon = Icon(
                      controller.value.isPlaying
                          ? Icons.pause
                          : Icons.play_arrow_sharp,
                      color: ColorResource.primaryColor,
                      size: 50,
                    );
                    return defaultIcon;
                  }(),
                ),
              ),
              InkWell(
                onTap: () {
                  controller.fastForward().then((value) {
                    widget.onFastForward?.call(controller.value);
                  });
                },
                child: const SizedBox(
                  height: 50,
                  width: 50,
                  child: Icon(
                    Icons.fast_forward_rounded,
                    color: ColorResource.primaryColor,
                    size: 25,
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(bottom: fullScreen ? 15 : 0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Row(
                children: [
                  Expanded(
                      child: PlayerBottomBar(
                    controller: controller,
                    videoSeek: videoSeek ?? '00:00:00',
                    videoDuration: videoDuration ?? '00:00:00',
                    videoStyle: widget.videoStyle,
                    showBottomBar: showMenu,
                    onPlayButtonTap: () => togglePlay(),
                    onFastForward: (value) {
                      widget.onFastForward?.call(value);
                    },
                    onRewind: (value) {
                      widget.onRewind?.call(value);
                    },
                  )),
                  const SizedBox(
                    width: 10,
                  ),

                  /// **Playback speed button** with PopupMenuButton styling
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, bottom: 3),
                    child: PopupMenuButton<double>(
                      offset: const Offset(0, 40), // Controls the popup position
                      onSelected: (speed) {
                        setState(() {
                          _playbackSpeed = speed; // Update playback speed
                          controller.setPlaybackSpeed(speed);
                        });
                      },
                      itemBuilder: (context) => [
                        buildPopupMenuItem(
                          value: 0.5,
                          text: "0.5x",
                          icon: Icons.slow_motion_video,
                          selectedSpeed: _playbackSpeed,
                        ),
                        buildPopupMenuItem(
                          value: 1.0,
                          text: "1.0x (Normal)",
                          icon: Icons.play_arrow,
                          selectedSpeed: _playbackSpeed,
                        ),
                        buildPopupMenuItem(
                          value: 1.5,
                          text: "1.5x",
                          icon: Icons.fast_forward,
                          selectedSpeed: _playbackSpeed,
                        ),
                        buildPopupMenuItem(
                          value: 2.0,
                          text: "2.0x",
                          icon: Icons.fast_forward,
                          selectedSpeed: _playbackSpeed,
                        ),

                      ],
                      child: const Icon(
                        Icons.speed,
                        color: ColorResource.primaryColor,
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  InkWell(
                    onTap: () => ScreenUtils.toggleFullScreen(fullScreen),
                    child: Icon(
                      fullScreen ? Icons.fullscreen_exit : Icons.fullscreen,
                      color: ColorResource.primaryColor,
                      size: 20,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Video player live direct button
  Widget liveDirectButton() {
    return Visibility(
      visible: widget.videoStyle.showLiveDirectButton && showMenu,
      child: Align(
        alignment: Alignment.topLeft,
        child: IntrinsicWidth(
          child: InkWell(
            onTap: () {
              controller.seekTo(controller.value.duration).then((value) {
                widget.onLiveDirectTap?.call(controller.value);
                controller.play();
              });
            },
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14.0,
                vertical: 14.0,
              ),
              margin: const EdgeInsets.only(left: 9.0),
              child: Row(
                children: [
                  Container(
                    width: widget.videoStyle.liveDirectButtonSize,
                    height: widget.videoStyle.liveDirectButtonSize,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isAtLivePosition
                          ? widget.videoStyle.liveDirectButtonColor
                          : widget.videoStyle.liveDirectButtonDisableColor,
                    ),
                  ),
                  const SizedBox(width: 8.0),
                  Text(
                    widget.videoStyle.liveDirectButtonText ?? 'Live',
                    style: widget.videoStyle.liveDirectButtonTextStyle ??
                        const TextStyle(color: Colors.white, fontSize: 16.0),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Video quality list
  Widget m3u8List() {
    RenderBox? renderBox =
        videoQualityKey.currentContext?.findRenderObject() as RenderBox?;
    var offset = renderBox?.localToGlobal(Offset.zero);
    // for(M3U8Data autoData in yoyo) {
    //   logPrint("audio data ${autoData.dataQuality}");
    // }
    M3U8Data autoData = yoyo.firstWhere(
        (element) => element.dataQuality == "Auto",
        orElse: () => M3U8Data(dataQuality: "Auto", dataURL: "videoUrl"));
    List<M3U8Data> yoyoDup = [];
    for (var dup in yoyo) {
      if (yoyoDup.any((element) => element.dataQuality == dup.dataQuality)) {
        //logPrint("Duplicate in List= ${dup}");
      } else {
        yoyoDup.add(dup);
      }
    }
    yoyoDup.removeWhere((element) => element.dataQuality == "Auto");
    yoyoDup.sort((a, b) {
      int aList = int.tryParse(
              a.dataQuality?.split("x")[1].removeAllWhitespace ?? "") ??
          0;
      int bList = int.tryParse(
              b.dataQuality?.split("x")[1].removeAllWhitespace ?? "") ??
          0;
      return bList.compareTo(aList);
    });
    yoyoDup.insert(0, autoData);
    return VideoQualityPicker(
      videoData: yoyoDup,
      videoStyle: widget.videoStyle,
      showPicker: m3u8Show,
      positionRight: (renderBox?.size.width ?? 0.0) / 3,
      positionTop: (offset?.dy ?? 0.0) + 35.0,
      onQualitySelected: (data) {
        if (data.dataQuality != m3u8Quality) {
          setState(() {
            m3u8Quality = data.dataQuality ?? m3u8Quality;
          });
          onSelectQuality(data);
        }
        setState(() {
          m3u8Show = false;
        });
        removeOverlay();
      },
    );
  }

  void urlCheck(String url) {
    final netRegex = RegExp(RegexResponse.regexHTTP);
    final isNetwork = netRegex.hasMatch(url);
    final uri = Uri.parse(url);

    if (isNetwork) {
      setState(() {
        isOffline = false;
      });
      if (uri.pathSegments.last.endsWith("mkv")) {
        setState(() {
          playType = "MKV";
        });
        widget.onPlayingVideo?.call("MKV");

        videoControlSetup(url);

        if (widget.allowCacheFile) {
          FileUtils.cacheFileToLocalStorage(
            url,
            fileExtension: 'mkv',
            headers: widget.headers,
            onSaveCompleted: (file) {
              widget.onCacheFileCompleted?.call(file != null ? [file] : null);
            },
            onSaveFailed: widget.onCacheFileFailed,
          );
        }
      } else if (uri.pathSegments.last.endsWith("mp4")) {
        setState(() {
          playType = "MP4";
        });
        widget.onPlayingVideo?.call("MP4");

        videoControlSetup(url);

        if (widget.allowCacheFile) {
          FileUtils.cacheFileToLocalStorage(
            url,
            fileExtension: 'mp4',
            headers: widget.headers,
            onSaveCompleted: (file) {
              widget.onCacheFileCompleted?.call(file != null ? [file] : null);
            },
            onSaveFailed: widget.onCacheFileFailed,
          );
        }
      } else if (uri.pathSegments.last.endsWith('webm')) {
        setState(() {
          playType = "WEBM";
        });

        widget.onPlayingVideo?.call("WEBM");

        videoControlSetup(url);

        if (widget.allowCacheFile) {
          FileUtils.cacheFileToLocalStorage(
            url,
            fileExtension: 'webm',
            headers: widget.headers,
            onSaveCompleted: (file) {
              widget.onCacheFileCompleted?.call(file != null ? [file] : null);
            },
            onSaveFailed: widget.onCacheFileFailed,
          );
        }
      } else if (uri.pathSegments.last.endsWith("m3u8")) {
        setState(() {
          playType = "HLS";
        });
        widget.onPlayingVideo?.call("M3U8");

        videoControlSetup(url);
        getM3U8(url);
      } else {
        videoControlSetup(url);
        getM3U8(url);
      }
    } else {
      setState(() {
        isOffline = true;
      });

      videoControlSetup(url);
    }
  }

  /// M3U8 Data Setup
  void getM3U8(String videoUrl) {
    if (yoyo.isNotEmpty) {
      m3u8Clean();
    }
    m3u8Video(videoUrl);
  }

  Future<M3U8s?> m3u8Video(String? videoUrl) async {
    yoyo.add(M3U8Data(dataQuality: "Auto", dataURL: videoUrl));

    RegExp regExpAudio = RegExp(
      RegexResponse.regexMEDIA,
      caseSensitive: false,
      multiLine: true,
    );

    RegExp regExp = RegExp(
      RegexResponse.regexM3U8Resolution,
      caseSensitive: false,
      multiLine: true,
    );

    if (m3u8Content != null) {
      setState(() {
        m3u8Content = null;
      });
    }

    if (m3u8Content == null && videoUrl != null) {
      http.Response response =
          await http.get(Uri.parse(videoUrl), headers: widget.headers);

      if (response.statusCode == 200) {
        m3u8Content = utf8.decode(response.bodyBytes);

        List<File> cachedFiles = [];
        int index = 0;

        List<RegExpMatch> matches =
            regExp.allMatches(m3u8Content ?? '').toList();
        List<RegExpMatch> audioMatches =
            regExpAudio.allMatches(m3u8Content ?? '').toList();

        matches.forEach(
          (RegExpMatch regExpMatch) async {
            String quality = (regExpMatch.group(1)).toString();
            String sourceURL = (regExpMatch.group(3)).toString();
            final netRegex = RegExp(RegexResponse.regexHTTP);
            final netRegex2 = RegExp(RegexResponse.regexURL);
            final isNetwork = netRegex.hasMatch(sourceURL);
            final match = netRegex2.firstMatch(videoUrl);
            String url;
            if (isNetwork) {
              url = sourceURL;
            } else {
              final dataURL = match?.group(0);
              url = "$dataURL$sourceURL";
            }
            audioMatches.forEach(
              (RegExpMatch regExpMatch2) async {
                String audioURL = (regExpMatch2.group(1)).toString();
                final isNetwork = netRegex.hasMatch(audioURL);
                final match = netRegex2.firstMatch(videoUrl);
                String auURL = audioURL;

                if (!isNetwork) {
                  final auDataURL = match!.group(0);
                  auURL = "$auDataURL$audioURL";
                }

                audioList.add(AudioModel(url: auURL));
              },
            );

            String audio = "";
            logPrint("-- Audio ---\nAudio list length: ${audio.length}");
            if (audioList.isNotEmpty) {
              audio =
                  """#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio-medium",NAME="audio",AUTOSELECT=YES,DEFAULT=YES,CHANNELS="2",
                  URI="${audioList.last.url}"\n""";
            } else {
              audio = "";
            }

            if (widget.allowCacheFile) {
              try {
                var file = await FileUtils.cacheFileUsingWriteAsString(
                  contents:
                      """#EXTM3U\n#EXT-X-INDEPENDENT-SEGMENTS\n$audio#EXT-X-STREAM-INF:CLOSED-CAPTIONS=NONE,BANDWIDTH=1469712,
                  RESOLUTION=$quality,FRAME-RATE=30.000\n$url""",
                  quality: quality,
                  videoUrl: url,
                );

                cachedFiles.add(file);

                if (index < matches.length) {
                  index++;
                }

                if (widget.allowCacheFile && index == matches.length) {
                  widget.onCacheFileCompleted
                      ?.call(cachedFiles.isEmpty ? null : cachedFiles);
                }
              } catch (e) {
                logPrint("Couldn't write file: $e");
                widget.onCacheFileFailed?.call(e);
              }
            }

            yoyo.add(M3U8Data(dataQuality: quality, dataURL: url));
          },
        );

        for (M3U8Data data in yoyo) {
          logPrint("data is datata ${data.dataQuality}");
        }

        M3U8s m3u8s = M3U8s(m3u8s: yoyo);

        logPrint(
            "--- m3u8 File write --- ${yoyo.map((e) => e.dataQuality == e.dataURL).toList()} --- length : ${yoyo.length} --- Success");
        return m3u8s;
      }
    }

    return null;
  }

// Init video controller
  void videoControlSetup(String? url) async {
    videoInit(url);

    controller.addListener(listener);
    controller.setPlaybackSpeed(_playbackSpeed);

    if (widget.autoPlayVideoAfterInit) {
      controller.play();
    }
    widget.onVideoInitCompleted?.call(controller);
  }

// Video listener
  void listener() async {
    if (controller.value.position.inSeconds + 1 ==
        controller.value.duration.inSeconds) {
      logPrint("i am completed");
      if (controller.value.isPlaying) {
        controller.pause().then((_) {
          logPrint("i am paused");

          widget.onPlayButtonTap?.call(controller.value.isPlaying);
        });
      }
    }

    if (widget.videoStyle.showLiveDirectButton) {
      if (controller.value.position != controller.value.duration) {
        if (isAtLivePosition) {
          setState(() {
            isAtLivePosition = false;
          });
        }
      } else {
        if (!isAtLivePosition) {
          setState(() {
            isAtLivePosition = true;
          });
        }
      }
    }
    if (controller.value.isInitialized && controller.value.isPlaying) {
      // if (!await Wakelock.enabled) {
      //   await Wakelock.enable();
      // }
      setState(() {
        videoDuration = controller.value.duration.convertDurationToString();
        videoSeek = controller.value.position.convertDurationToString();
        videoSeekSecond = controller.value.position.inSeconds.toDouble();
        videoDurationSecond = controller.value.duration.inSeconds.toDouble();
      });
      widget.onVideoPosition?.call(controller.value.position.inSeconds,
          controller.value.duration.inSeconds);
    } else {
      // if (await Wakelock.enabled) {
      //   // await Wakelock.disable();
      //   setState(() {});
      // }
    }
  }

  void createHideControlBarTimer() {
    clearHideControlBarTimer();
    showTime = Timer(const Duration(milliseconds: 5000), () {
      // if (controller != null && controller.value.isPlaying) {
      if (controller.value.isPlaying) {
        if (showMenu) {
          setState(() {
            showMenu = false;
            m3u8Show = false;
            controlBarAnimationController.reverse();

            widget.onShowMenu?.call(showMenu, m3u8Show);
            removeOverlay();
          });
        }
      }
    });
  }

  void clearHideControlBarTimer() {
    showTime?.cancel();
  }

  void toggleControls() {
    clearHideControlBarTimer();

    if (!showMenu) {
      setState(() {
        showMenu = true;
      });
      widget.onShowMenu?.call(showMenu, m3u8Show);

      createHideControlBarTimer();
    } else {
      setState(() {
        m3u8Show = false;
        showMenu = false;
      });

      widget.onShowMenu?.call(showMenu, m3u8Show);
    }
    // setState(() {
    if (showMenu) {
      controlBarAnimationController.forward();
    } else {
      controlBarAnimationController.reverse();
    }
    // });
  }

  void togglePlay() {
    createHideControlBarTimer();
    if (controller.value.isPlaying) {
      controller.pause().then((_) {
        logPrint("i am paused");
        widget.onPlayButtonTap?.call(controller.value.isPlaying);
      });
    } else {
      logPrint("i am played");

      controller.play().then((_) {
        widget.onPlayButtonTap?.call(controller.value.isPlaying);
      });
    }
    setState(() {});
  }

  void videoInit(String? url) {
    if (isOffline == false) {
      logPrint(
          "--- Player status ---\nplay url : $url\noffline : $isOffline\n--- start playing –––");

      if (playType == "MP4" || playType == "WEBM") {
        // Play MP4 and WEBM video
        controller = VideoPlayerController.network(
          url!,
          formatHint: VideoFormat.other,
          httpHeaders: widget.headers ?? const <String, String>{},
          closedCaptionFile: widget.closedCaptionFile,
          videoPlayerOptions: widget.videoPlayerOptions,
        )..initialize().then((value) => seekToLastPlayingPosition);
      } else if (playType == "MKV") {
        controller = VideoPlayerController.network(
          url!,
          formatHint: VideoFormat.dash,
          httpHeaders: widget.headers ?? const <String, String>{},
          closedCaptionFile: widget.closedCaptionFile,
          videoPlayerOptions: widget.videoPlayerOptions,
        )..initialize().then((value) => seekToLastPlayingPosition);
      } else if (playType == "HLS") {
        controller = VideoPlayerController.network(
          url!,
          formatHint: VideoFormat.hls,
          httpHeaders: widget.headers ?? const <String, String>{},
          closedCaptionFile: widget.closedCaptionFile,
          videoPlayerOptions: widget.videoPlayerOptions,
        )..initialize().then((_) {
            setState(() => hasInitError = false);
            seekToLastPlayingPosition();
          }).catchError((e) {
            setState(() => hasInitError = true);
          });
      }
    } else {
      logPrint(
          "--- Player status ---\nplay url : $url\noffline : $isOffline\n--- start playing –––");
      controller = VideoPlayerController.file(
        File(url!),
        closedCaptionFile: widget.closedCaptionFile,
        videoPlayerOptions: widget.videoPlayerOptions,
      )..initialize().then((value) {
          setState(() => hasInitError = false);
          seekToLastPlayingPosition();
        }).catchError((e) {
          setState(() => hasInitError = true);
        });
    }
  }

  void _navigateLocally(context) async {
    if (!fullScreen) {
      if (ModalRoute.of(context)?.willHandlePopInternally ?? false) {
        Navigator.of(context).pop();
      }
      return;
    }

    ModalRoute.of(context)?.addLocalHistoryEntry(
      LocalHistoryEntry(
        onRemove: () {
          if (fullScreen) ScreenUtils.toggleFullScreen(fullScreen);
        },
      ),
    );
  }

  void onSelectQuality(M3U8Data data) async {
    lastPlayedPos = await controller.position;

    if (controller.value.isPlaying) {
      await controller.pause();
    }

    if (data.dataQuality == "Auto") {
      videoControlSetup(data.dataURL);
    } else {
      try {
        String text;
        var file = await FileUtils.readFileFromPath(
            videoUrl: data.dataURL ?? '', quality: data.dataQuality ?? '');
        if (file != null) {
          logPrint("Start reading file");
          text = await file.readAsString();
          logPrint("Video file data: $text");

          if (data.dataURL != null) {
            playLocalM3U8File(data.dataURL!);
          } else {
            logPrint('Play ${data.dataQuality} m3u8 video file failed');
          }
          // videoControlSetup(file);
        }
      } catch (e) {
        logPrint("Couldn't read file ${data.dataQuality}: $e");
      }
    }
  }

  void playLocalM3U8File(String url) {
    controller.dispose();
    controller = VideoPlayerController.network(
      url,
      closedCaptionFile: widget.closedCaptionFile,
      videoPlayerOptions: widget.videoPlayerOptions,
    )..initialize().then((_) {
        setState(() => hasInitError = false);
        seekToLastPlayingPosition();
        controller.play();
      }).catchError((e) {
        setState(() => hasInitError = true);
        logPrint('Init local file error $e');
      });

    controller.addListener(listener);
    controller.play();
  }

  void m3u8Clean() async {
    logPrint('Video list length: ${yoyo.length}');
    for (int i = 2; i < yoyo.length; i++) {
      try {
        var file = await FileUtils.readFileFromPath(
            videoUrl: yoyo[i].dataURL ?? '',
            quality: yoyo[i].dataQuality ?? '');
        var exists = await file?.exists();
        if (exists ?? false) {
          await file?.delete();
          logPrint("Delete success $file");
        }
      } catch (e) {
        logPrint("Couldn't delete file $e");
      }
    }
    try {
      logPrint("Cleaning audio m3u8 list");
      audioList.clear();
      logPrint("Cleaning audio m3u8 list completed");
    } catch (e) {
      logPrint("Audio list clean error $e");
    }
    audioList.clear();
    try {
      logPrint("Cleaning m3u8 data list");
      yoyo.clear();
      logPrint("Cleaning m3u8 data list completed");
    } catch (e) {
      logPrint("m3u8 video list clean error $e");
    }
  }

  void showOverlay() {
    setState(() {
      overlayEntry = OverlayEntry(
        builder: (_) => m3u8List(),
      );
      Overlay.of(context).insert(overlayEntry!);
    });
  }

  void removeOverlay() {
    setState(() {
      overlayEntry?.remove();
      overlayEntry = null;
    });
  }

  void seekToLastPlayingPosition() {
    if (lastPlayedPos != null) {
      controller.seekTo(lastPlayedPos!);
      widget.onVideoInitCompleted?.call(controller);
      lastPlayedPos = null;
    }
  }
}
/// Helper function to build PopupMenuItem with custom styling
PopupMenuItem<double> buildPopupMenuItem({
  required double value,
  required String text,
  required IconData icon,
  required double selectedSpeed,
}) {
  return PopupMenuItem<double>(
    value: value,
    height: 35,  // Adjust height for compactness
    child: Row(
      children: [
        Icon(
          icon,
          color: selectedSpeed == value
              ? ColorResource.primaryColor
              : Colors.grey.shade700,  // Icon color
          size: 14,  // Smaller icon size
        ),
        const SizedBox(width: 6),  // Space between icon and text
        Text(
          text,
          style: TextStyle(
            fontSize: 12,  // Smaller font size
            fontWeight: FontWeight.bold,
            color: selectedSpeed == value
                ? ColorResource.primaryColor
                : Colors.grey.shade900,  // Text color
          ),
        ),
      ],
    ),
  );
}
