

class NavigationResource {
  static NavigationResource? _instance;
  static NavigationResource get instance => _instance ??= NavigationResource._init();
  NavigationResource._init();

}
