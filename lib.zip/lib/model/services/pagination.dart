// ignore_for_file: constant_identifier_names

import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import '../utils/color_resource.dart';
import '../utils/dimensions_resource.dart';

enum APISTATUS {
  LOADING,
  SUCEESS,
  ERROR,
  HIDELOADER;
}

class PaginationView<T> extends StatelessWidget {
  final Widget Function(BuildContext context, int index, T item) itemBuilder;
  final Widget Function(BuildContext context) errorBuilder;
  final Widget Function(BuildContext context) bottomLoaderBuilder;
  final Future Function() onRefresh;
  final PagingScrollController<T> pagingScrollController;

  const PaginationView({
    Key? key,
    required this.itemBuilder,
    required this.errorBuilder,
    required this.bottomLoaderBuilder,
    required this.pagingScrollController,
    required this.onRefresh,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: ColorResource.primaryColor,
      onRefresh: onRefresh,
      child: Obx(() => ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.only(top: 0),
            physics: const AlwaysScrollableScrollPhysics(),
            controller: pagingScrollController.scrollController,
            // child: Obx(()=>Column(
            children: [
              ...List.generate(
                  pagingScrollController.list.length,
                  (index) => itemBuilder(context, index,
                      pagingScrollController.list.elementAt(index))),
              Visibility(
                  visible: pagingScrollController.isDataLoading.value,
                  child: bottomLoaderBuilder(context)),
            ],
            //  ),
            //)
          )),
    );
  }
}

class GridPaginationView<T> extends StatelessWidget {
  final Widget Function(BuildContext context, int index, T item) itemBuilder;
  final Widget Function(BuildContext context) errorBuilder;
  final Widget Function(BuildContext context) bottomLoaderBuilder;
  final Future Function() onRefresh;
  final bool isRectangle;
  final double aspectRatio;
  final PagingScrollController<T> pagingScrollController;

  const GridPaginationView(
      {Key? key,
      required this.itemBuilder,
      required this.errorBuilder,
      required this.bottomLoaderBuilder,
      required this.pagingScrollController,
      required this.onRefresh,
      required this.isRectangle,
      this.aspectRatio = 1})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.only(
          left: DimensionResource.marginSizeDefault,
          right: DimensionResource.marginSizeDefault,
          top: DimensionResource.marginSizeSmall),
      sliver: SliverAnimatedGrid(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: DimensionResource.marginSizeSmall,
              mainAxisSpacing: DimensionResource.marginSizeSmall,
              childAspectRatio: isRectangle ? 1.8 : aspectRatio),
          initialItemCount: pagingScrollController.list.length,
          itemBuilder: (context, index, animationVal) {
            return itemBuilder(
                context, index, pagingScrollController.list.elementAt(index));
          }),
    );
  }
}

class PagingScrollController<T> {
  final ScrollController scrollController = ScrollController();
  bool _loading = true;
  int _currentPage = 0;
  int _previousItemsCount = 0;

  RxList<T> list = <T>[].obs;

  RxBool isDataLoading = false.obs;
  var apiStatus = APISTATUS.HIDELOADER.obs;

  final Function(int page, int totalItemsCount) onLoadMore;
  final int Function() getStartPage;
  final int Function() getThreshold;

  PagingScrollController(
      {required this.onLoadMore,
      required this.getStartPage,
      required this.getThreshold}) {
    _currentPage = getStartPage();
    scrollController.addListener(_scrollListener);
  }

  get _scrollListener => () {
        //logPrint("--->"+"inscrooll+${_scrollController.position.maxScrollExtent}");
        int latestItemsCount = list.length;

        if (latestItemsCount < _previousItemsCount) {
          _currentPage = getStartPage();
          _previousItemsCount = latestItemsCount;
          if (latestItemsCount == 0) {
            _loading = true;
          }
        }
        if (_loading && latestItemsCount > _previousItemsCount) {
          _loading = false;
          _previousItemsCount = latestItemsCount;
        }

        var nextPageTrigger = 0.2 * scrollController.position.maxScrollExtent;

        if (scrollController.position.userScrollDirection ==
            ScrollDirection.reverse) {
          if (!_loading && scrollController.position.pixels > nextPageTrigger) {
            _currentPage++;
            onLoadMore(_currentPage, latestItemsCount);
            _loading = true;
          }

          // if (!_loading &&
          //     scrollController.position.maxScrollExtent - _threshold ==
          //         scrollController.position.pixels) {
          //   _currentPage++;
          //   onLoadMore(_currentPage, latestItemsCount);
          //   _loading = true;
          // }
        }
      };

  void reset() {
    _loading = true;
    _currentPage = getStartPage();
    _previousItemsCount = 0;
    list.clear();
    isDataLoading.value = false;
    log("List length $list");
    log("Pagging Controller Reset Call");
  }
}
